gdjs.forestCode = {};
gdjs.forestCode.GDNoButtonObjects2_1final = [];

gdjs.forestCode.GDYesButtonObjects2_1final = [];

gdjs.forestCode.GDTransitionObjects1= [];
gdjs.forestCode.GDTransitionObjects2= [];
gdjs.forestCode.GDTransitionObjects3= [];
gdjs.forestCode.GDTransitionObjects4= [];
gdjs.forestCode.GDPlayerObjects1= [];
gdjs.forestCode.GDPlayerObjects2= [];
gdjs.forestCode.GDPlayerObjects3= [];
gdjs.forestCode.GDPlayerObjects4= [];
gdjs.forestCode.GDDock1Objects1= [];
gdjs.forestCode.GDDock1Objects2= [];
gdjs.forestCode.GDDock1Objects3= [];
gdjs.forestCode.GDDock1Objects4= [];
gdjs.forestCode.GDFishermanObjects1= [];
gdjs.forestCode.GDFishermanObjects2= [];
gdjs.forestCode.GDFishermanObjects3= [];
gdjs.forestCode.GDFishermanObjects4= [];
gdjs.forestCode.GDWater1Objects1= [];
gdjs.forestCode.GDWater1Objects2= [];
gdjs.forestCode.GDWater1Objects3= [];
gdjs.forestCode.GDWater1Objects4= [];
gdjs.forestCode.GDTextBorderObjects1= [];
gdjs.forestCode.GDTextBorderObjects2= [];
gdjs.forestCode.GDTextBorderObjects3= [];
gdjs.forestCode.GDTextBorderObjects4= [];
gdjs.forestCode.GDCollisionDetectObjects1= [];
gdjs.forestCode.GDCollisionDetectObjects2= [];
gdjs.forestCode.GDCollisionDetectObjects3= [];
gdjs.forestCode.GDCollisionDetectObjects4= [];
gdjs.forestCode.GDEObjects1= [];
gdjs.forestCode.GDEObjects2= [];
gdjs.forestCode.GDEObjects3= [];
gdjs.forestCode.GDEObjects4= [];
gdjs.forestCode.GDAObjects1= [];
gdjs.forestCode.GDAObjects2= [];
gdjs.forestCode.GDAObjects3= [];
gdjs.forestCode.GDAObjects4= [];
gdjs.forestCode.GDA2Objects1= [];
gdjs.forestCode.GDA2Objects2= [];
gdjs.forestCode.GDA2Objects3= [];
gdjs.forestCode.GDA2Objects4= [];
gdjs.forestCode.GDDialogueObjects1= [];
gdjs.forestCode.GDDialogueObjects2= [];
gdjs.forestCode.GDDialogueObjects3= [];
gdjs.forestCode.GDDialogueObjects4= [];
gdjs.forestCode.GDDialogue4Objects1= [];
gdjs.forestCode.GDDialogue4Objects2= [];
gdjs.forestCode.GDDialogue4Objects3= [];
gdjs.forestCode.GDDialogue4Objects4= [];
gdjs.forestCode.GDYesButtonObjects1= [];
gdjs.forestCode.GDYesButtonObjects2= [];
gdjs.forestCode.GDYesButtonObjects3= [];
gdjs.forestCode.GDYesButtonObjects4= [];
gdjs.forestCode.GDNoButtonObjects1= [];
gdjs.forestCode.GDNoButtonObjects2= [];
gdjs.forestCode.GDNoButtonObjects3= [];
gdjs.forestCode.GDNoButtonObjects4= [];
gdjs.forestCode.GDCornerWaterObjects1= [];
gdjs.forestCode.GDCornerWaterObjects2= [];
gdjs.forestCode.GDCornerWaterObjects3= [];
gdjs.forestCode.GDCornerWaterObjects4= [];
gdjs.forestCode.GDWaterEdgeRightObjects1= [];
gdjs.forestCode.GDWaterEdgeRightObjects2= [];
gdjs.forestCode.GDWaterEdgeRightObjects3= [];
gdjs.forestCode.GDWaterEdgeRightObjects4= [];
gdjs.forestCode.GDNewTiledSpriteObjects1= [];
gdjs.forestCode.GDNewTiledSpriteObjects2= [];
gdjs.forestCode.GDNewTiledSpriteObjects3= [];
gdjs.forestCode.GDNewTiledSpriteObjects4= [];
gdjs.forestCode.GDGrassObjects1= [];
gdjs.forestCode.GDGrassObjects2= [];
gdjs.forestCode.GDGrassObjects3= [];
gdjs.forestCode.GDGrassObjects4= [];
gdjs.forestCode.GDTree2Objects1= [];
gdjs.forestCode.GDTree2Objects2= [];
gdjs.forestCode.GDTree2Objects3= [];
gdjs.forestCode.GDTree2Objects4= [];
gdjs.forestCode.GDNPC2Objects1= [];
gdjs.forestCode.GDNPC2Objects2= [];
gdjs.forestCode.GDNPC2Objects3= [];
gdjs.forestCode.GDNPC2Objects4= [];
gdjs.forestCode.GDBush1Objects1= [];
gdjs.forestCode.GDBush1Objects2= [];
gdjs.forestCode.GDBush1Objects3= [];
gdjs.forestCode.GDBush1Objects4= [];
gdjs.forestCode.GDLakeTroutObjects1= [];
gdjs.forestCode.GDLakeTroutObjects2= [];
gdjs.forestCode.GDLakeTroutObjects3= [];
gdjs.forestCode.GDLakeTroutObjects4= [];
gdjs.forestCode.GDFenceObjects1= [];
gdjs.forestCode.GDFenceObjects2= [];
gdjs.forestCode.GDFenceObjects3= [];
gdjs.forestCode.GDFenceObjects4= [];
gdjs.forestCode.GDfencepostObjects1= [];
gdjs.forestCode.GDfencepostObjects2= [];
gdjs.forestCode.GDfencepostObjects3= [];
gdjs.forestCode.GDfencepostObjects4= [];
gdjs.forestCode.GDTreesObjects1= [];
gdjs.forestCode.GDTreesObjects2= [];
gdjs.forestCode.GDTreesObjects3= [];
gdjs.forestCode.GDTreesObjects4= [];
gdjs.forestCode.GDAppleObjects1= [];
gdjs.forestCode.GDAppleObjects2= [];
gdjs.forestCode.GDAppleObjects3= [];
gdjs.forestCode.GDAppleObjects4= [];

gdjs.forestCode.conditionTrue_0 = {val:false};
gdjs.forestCode.condition0IsTrue_0 = {val:false};
gdjs.forestCode.condition1IsTrue_0 = {val:false};
gdjs.forestCode.condition2IsTrue_0 = {val:false};
gdjs.forestCode.conditionTrue_1 = {val:false};
gdjs.forestCode.condition0IsTrue_1 = {val:false};
gdjs.forestCode.condition1IsTrue_1 = {val:false};
gdjs.forestCode.condition2IsTrue_1 = {val:false};


gdjs.forestCode.mapOfGDgdjs_46forestCode_46GDCollisionDetectObjects1Objects = Hashtable.newFrom({"CollisionDetect": gdjs.forestCode.GDCollisionDetectObjects1});
gdjs.forestCode.eventsList0 = function(runtimeScene) {

{


gdjs.forestCode.condition0IsTrue_0.val = false;
{
{gdjs.forestCode.conditionTrue_1 = gdjs.forestCode.condition0IsTrue_0;
gdjs.forestCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15715220);
}
}if (gdjs.forestCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("E"), gdjs.forestCode.GDEObjects2);
gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.forestCode.GDNoButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.forestCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.forestCode.GDYesButtonObjects2);
{for(var i = 0, len = gdjs.forestCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.forestCode.GDPlayerObjects2[i].activateBehavior("TopDownMovement", true);
}
}{for(var i = 0, len = gdjs.forestCode.GDEObjects2.length ;i < len;++i) {
    gdjs.forestCode.GDEObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.forestCode.GDYesButtonObjects2.length ;i < len;++i) {
    gdjs.forestCode.GDYesButtonObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.forestCode.GDNoButtonObjects2.length ;i < len;++i) {
    gdjs.forestCode.GDNoButtonObjects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.forestCode.GDPlayerObjects2);

gdjs.forestCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.forestCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.forestCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isUsingControl("Up") ) {
        gdjs.forestCode.condition0IsTrue_0.val = true;
        gdjs.forestCode.GDPlayerObjects2[k] = gdjs.forestCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.forestCode.GDPlayerObjects2.length = k;}if (gdjs.forestCode.condition0IsTrue_0.val) {
/* Reuse gdjs.forestCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.forestCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.forestCode.GDPlayerObjects2[i].setAnimationName("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.forestCode.GDPlayerObjects2);

gdjs.forestCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.forestCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.forestCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isUsingControl("Down") ) {
        gdjs.forestCode.condition0IsTrue_0.val = true;
        gdjs.forestCode.GDPlayerObjects2[k] = gdjs.forestCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.forestCode.GDPlayerObjects2.length = k;}if (gdjs.forestCode.condition0IsTrue_0.val) {
/* Reuse gdjs.forestCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.forestCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.forestCode.GDPlayerObjects2[i].setAnimationName("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.forestCode.GDPlayerObjects2);

gdjs.forestCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.forestCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.forestCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isUsingControl("Right") ) {
        gdjs.forestCode.condition0IsTrue_0.val = true;
        gdjs.forestCode.GDPlayerObjects2[k] = gdjs.forestCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.forestCode.GDPlayerObjects2.length = k;}if (gdjs.forestCode.condition0IsTrue_0.val) {
/* Reuse gdjs.forestCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.forestCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.forestCode.GDPlayerObjects2[i].setAnimationName("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.forestCode.GDPlayerObjects2);

gdjs.forestCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.forestCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.forestCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isUsingControl("Left") ) {
        gdjs.forestCode.condition0IsTrue_0.val = true;
        gdjs.forestCode.GDPlayerObjects2[k] = gdjs.forestCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.forestCode.GDPlayerObjects2.length = k;}if (gdjs.forestCode.condition0IsTrue_0.val) {
/* Reuse gdjs.forestCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.forestCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.forestCode.GDPlayerObjects2[i].setAnimationName("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.forestCode.GDPlayerObjects2);

gdjs.forestCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.forestCode.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.forestCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isMoving()) ) {
        gdjs.forestCode.condition0IsTrue_0.val = true;
        gdjs.forestCode.GDPlayerObjects2[k] = gdjs.forestCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.forestCode.GDPlayerObjects2.length = k;}if (gdjs.forestCode.condition0IsTrue_0.val) {
/* Reuse gdjs.forestCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.forestCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.forestCode.GDPlayerObjects2[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.forestCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.forestCode.GDPlayerObjects2[i].setAnimationFrame(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.forestCode.GDPlayerObjects1);

gdjs.forestCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.forestCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.forestCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").isMoving() ) {
        gdjs.forestCode.condition0IsTrue_0.val = true;
        gdjs.forestCode.GDPlayerObjects1[k] = gdjs.forestCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.forestCode.GDPlayerObjects1.length = k;}if (gdjs.forestCode.condition0IsTrue_0.val) {
/* Reuse gdjs.forestCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.forestCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.forestCode.GDPlayerObjects1[i].playAnimation();
}
}}

}


};gdjs.forestCode.eventsList1 = function(runtimeScene) {

{


gdjs.forestCode.condition0IsTrue_0.val = false;
{
gdjs.forestCode.condition0IsTrue_0.val = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Dialogue"));
}if (gdjs.forestCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.forestCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.forestCode.mapOfGDgdjs_46forestCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.forestCode.GDPlayerObjects2});
gdjs.forestCode.mapOfGDgdjs_46forestCode_46GDNPC2Objects2Objects = Hashtable.newFrom({"NPC2": gdjs.forestCode.GDNPC2Objects2});
gdjs.forestCode.eventsList2 = function(runtimeScene) {

{


gdjs.forestCode.condition0IsTrue_0.val = false;
gdjs.forestCode.condition1IsTrue_0.val = false;
{
gdjs.forestCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.forestCode.condition0IsTrue_0.val ) {
{
{gdjs.forestCode.conditionTrue_1 = gdjs.forestCode.condition1IsTrue_0;
gdjs.forestCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15729588);
}
}}
if (gdjs.forestCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("E"), gdjs.forestCode.GDEObjects2);
{gdjs.evtTools.camera.showLayer(runtimeScene, "Dialogue");
}{for(var i = 0, len = gdjs.forestCode.GDEObjects2.length ;i < len;++i) {
    gdjs.forestCode.GDEObjects2[i].hide();
}
}}

}


};gdjs.forestCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.forestCode.GDYesButtonObjects2, gdjs.forestCode.GDYesButtonObjects3);


gdjs.forestCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.forestCode.GDYesButtonObjects3.length;i<l;++i) {
    if ( gdjs.forestCode.GDYesButtonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.forestCode.condition0IsTrue_0.val = true;
        gdjs.forestCode.GDYesButtonObjects3[k] = gdjs.forestCode.GDYesButtonObjects3[i];
        ++k;
    }
}
gdjs.forestCode.GDYesButtonObjects3.length = k;}if (gdjs.forestCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.forestCode.GDDialogueObjects3);
gdjs.copyArray(runtimeScene.getObjects("Transition"), gdjs.forestCode.GDTransitionObjects3);
{for(var i = 0, len = gdjs.forestCode.GDTransitionObjects3.length ;i < len;++i) {
    gdjs.forestCode.GDTransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 1, "Circular", "Forward", 255, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "Dialogue");
}{for(var i = 0, len = gdjs.forestCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.forestCode.GDDialogueObjects3[i].hide();
}
}{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.forestCode.GDNoButtonObjects2);

gdjs.forestCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.forestCode.GDNoButtonObjects2.length;i<l;++i) {
    if ( gdjs.forestCode.GDNoButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.forestCode.condition0IsTrue_0.val = true;
        gdjs.forestCode.GDNoButtonObjects2[k] = gdjs.forestCode.GDNoButtonObjects2[i];
        ++k;
    }
}
gdjs.forestCode.GDNoButtonObjects2.length = k;}if (gdjs.forestCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Dialogue");
}}

}


};gdjs.forestCode.eventsList4 = function(runtimeScene) {

{


gdjs.forestCode.condition0IsTrue_0.val = false;
{
{gdjs.forestCode.conditionTrue_1 = gdjs.forestCode.condition0IsTrue_0;
gdjs.forestCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15758532);
}
}if (gdjs.forestCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.forestCode.GDDialogueObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.forestCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.forestCode.GDDialogueObjects2.length ;i < len;++i) {
    gdjs.forestCode.GDDialogueObjects2[i].getBehavior("BitmapText_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.forestCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.forestCode.GDPlayerObjects2[i].activateBehavior("TopDownMovement", false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Talk.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.forestCode.GDDialogueObjects2);

gdjs.forestCode.condition0IsTrue_0.val = false;
gdjs.forestCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.forestCode.GDDialogueObjects2.length;i<l;++i) {
    if ( gdjs.forestCode.GDDialogueObjects2[i].getBehavior("BitmapText_AutoTyping").TypingFinished((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.forestCode.condition0IsTrue_0.val = true;
        gdjs.forestCode.GDDialogueObjects2[k] = gdjs.forestCode.GDDialogueObjects2[i];
        ++k;
    }
}
gdjs.forestCode.GDDialogueObjects2.length = k;}if ( gdjs.forestCode.condition0IsTrue_0.val ) {
{
{gdjs.forestCode.conditionTrue_1 = gdjs.forestCode.condition1IsTrue_0;
gdjs.forestCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15770756);
}
}}
if (gdjs.forestCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.forestCode.GDNoButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.forestCode.GDYesButtonObjects2);
{for(var i = 0, len = gdjs.forestCode.GDYesButtonObjects2.length ;i < len;++i) {
    gdjs.forestCode.GDYesButtonObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.forestCode.GDNoButtonObjects2.length ;i < len;++i) {
    gdjs.forestCode.GDNoButtonObjects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.forestCode.GDYesButtonObjects2);

gdjs.forestCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.forestCode.GDYesButtonObjects2.length;i<l;++i) {
    if ( gdjs.forestCode.GDYesButtonObjects2[i].isVisible() ) {
        gdjs.forestCode.condition0IsTrue_0.val = true;
        gdjs.forestCode.GDYesButtonObjects2[k] = gdjs.forestCode.GDYesButtonObjects2[i];
        ++k;
    }
}
gdjs.forestCode.GDYesButtonObjects2.length = k;}if (gdjs.forestCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.forestCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.forestCode.GDNoButtonObjects2.length = 0;

gdjs.forestCode.GDYesButtonObjects2.length = 0;


gdjs.forestCode.condition0IsTrue_0.val = false;
gdjs.forestCode.condition1IsTrue_0.val = false;
{
{gdjs.forestCode.conditionTrue_1 = gdjs.forestCode.condition0IsTrue_0;
gdjs.forestCode.GDNoButtonObjects2_1final.length = 0;gdjs.forestCode.GDYesButtonObjects2_1final.length = 0;gdjs.forestCode.condition0IsTrue_1.val = false;
gdjs.forestCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.forestCode.GDNoButtonObjects3);
for(var i = 0, k = 0, l = gdjs.forestCode.GDNoButtonObjects3.length;i<l;++i) {
    if ( gdjs.forestCode.GDNoButtonObjects3[i].IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.forestCode.condition0IsTrue_1.val = true;
        gdjs.forestCode.GDNoButtonObjects3[k] = gdjs.forestCode.GDNoButtonObjects3[i];
        ++k;
    }
}
gdjs.forestCode.GDNoButtonObjects3.length = k;if( gdjs.forestCode.condition0IsTrue_1.val ) {
    gdjs.forestCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.forestCode.GDNoButtonObjects3.length;j<jLen;++j) {
        if ( gdjs.forestCode.GDNoButtonObjects2_1final.indexOf(gdjs.forestCode.GDNoButtonObjects3[j]) === -1 )
            gdjs.forestCode.GDNoButtonObjects2_1final.push(gdjs.forestCode.GDNoButtonObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.forestCode.GDYesButtonObjects3);
for(var i = 0, k = 0, l = gdjs.forestCode.GDYesButtonObjects3.length;i<l;++i) {
    if ( gdjs.forestCode.GDYesButtonObjects3[i].IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.forestCode.condition1IsTrue_1.val = true;
        gdjs.forestCode.GDYesButtonObjects3[k] = gdjs.forestCode.GDYesButtonObjects3[i];
        ++k;
    }
}
gdjs.forestCode.GDYesButtonObjects3.length = k;if( gdjs.forestCode.condition1IsTrue_1.val ) {
    gdjs.forestCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.forestCode.GDYesButtonObjects3.length;j<jLen;++j) {
        if ( gdjs.forestCode.GDYesButtonObjects2_1final.indexOf(gdjs.forestCode.GDYesButtonObjects3[j]) === -1 )
            gdjs.forestCode.GDYesButtonObjects2_1final.push(gdjs.forestCode.GDYesButtonObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.forestCode.GDNoButtonObjects2_1final, gdjs.forestCode.GDNoButtonObjects2);
gdjs.copyArray(gdjs.forestCode.GDYesButtonObjects2_1final, gdjs.forestCode.GDYesButtonObjects2);
}
}
}if ( gdjs.forestCode.condition0IsTrue_0.val ) {
{
{gdjs.forestCode.conditionTrue_1 = gdjs.forestCode.condition1IsTrue_0;
gdjs.forestCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15774276);
}
}}
if (gdjs.forestCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "HoverSound.wav", false, 20, gdjs.randomFloatInRange(0.8, 0.9));
}}

}


{


gdjs.forestCode.condition0IsTrue_0.val = false;
{
{gdjs.forestCode.conditionTrue_1 = gdjs.forestCode.condition0IsTrue_0;
gdjs.forestCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15775228);
}
}if (gdjs.forestCode.condition0IsTrue_0.val) {
}

}


};gdjs.forestCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NPC2"), gdjs.forestCode.GDNPC2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.forestCode.GDPlayerObjects2);

gdjs.forestCode.condition0IsTrue_0.val = false;
{
gdjs.forestCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.forestCode.mapOfGDgdjs_46forestCode_46GDPlayerObjects2Objects, gdjs.forestCode.mapOfGDgdjs_46forestCode_46GDNPC2Objects2Objects, 30, false);
}if (gdjs.forestCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.forestCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


gdjs.forestCode.condition0IsTrue_0.val = false;
{
gdjs.forestCode.condition0IsTrue_0.val = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Dialogue");
}if (gdjs.forestCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.forestCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.forestCode.eventsList6 = function(runtimeScene) {

};gdjs.forestCode.mapOfGDgdjs_46forestCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.forestCode.GDPlayerObjects1});
gdjs.forestCode.mapOfGDgdjs_46forestCode_46GDAppleObjects1Objects = Hashtable.newFrom({"Apple": gdjs.forestCode.GDAppleObjects1});
gdjs.forestCode.eventsList7 = function(runtimeScene) {

{


gdjs.forestCode.condition0IsTrue_0.val = false;
gdjs.forestCode.condition1IsTrue_0.val = false;
{
gdjs.forestCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if ( gdjs.forestCode.condition0IsTrue_0.val ) {
{
{gdjs.forestCode.conditionTrue_1 = gdjs.forestCode.condition1IsTrue_0;
gdjs.forestCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15776356);
}
}}
if (gdjs.forestCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("A2"), gdjs.forestCode.GDA2Objects1);
/* Reuse gdjs.forestCode.GDAppleObjects1 */
{for(var i = 0, len = gdjs.forestCode.GDAppleObjects1.length ;i < len;++i) {
    gdjs.forestCode.GDAppleObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.forestCode.GDA2Objects1.length ;i < len;++i) {
    gdjs.forestCode.GDA2Objects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().get("tree").add(1);
}}

}


};gdjs.forestCode.mapOfGDgdjs_46forestCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.forestCode.GDPlayerObjects1});
gdjs.forestCode.mapOfGDgdjs_46forestCode_46GDCollisionDetectObjects1Objects = Hashtable.newFrom({"CollisionDetect": gdjs.forestCode.GDCollisionDetectObjects1});
gdjs.forestCode.eventsList8 = function(runtimeScene) {

{


gdjs.forestCode.condition0IsTrue_0.val = false;
gdjs.forestCode.condition1IsTrue_0.val = false;
{
gdjs.forestCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if ( gdjs.forestCode.condition0IsTrue_0.val ) {
{
{gdjs.forestCode.conditionTrue_1 = gdjs.forestCode.condition1IsTrue_0;
gdjs.forestCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15777812);
}
}}
if (gdjs.forestCode.condition1IsTrue_0.val) {
/* Reuse gdjs.forestCode.GDCollisionDetectObjects1 */
{for(var i = 0, len = gdjs.forestCode.GDCollisionDetectObjects1.length ;i < len;++i) {
    gdjs.forestCode.GDCollisionDetectObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.forestCode.eventsList9 = function(runtimeScene) {

};gdjs.forestCode.eventsList10 = function(runtimeScene) {

{


gdjs.forestCode.condition0IsTrue_0.val = false;
{
gdjs.forestCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("tree")) >= 10;
}if (gdjs.forestCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().get("tasks").add(1);
}{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


};gdjs.forestCode.eventsList11 = function(runtimeScene) {

{


gdjs.forestCode.condition0IsTrue_0.val = false;
{
gdjs.forestCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.forestCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CollisionDetect"), gdjs.forestCode.GDCollisionDetectObjects1);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 6, "", 0);
}{for(var i = 0, len = gdjs.forestCode.GDCollisionDetectObjects1.length ;i < len;++i) {
    gdjs.forestCode.GDCollisionDetectObjects1[i].hide();
}
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1.5, "Transition", 0);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.forestCode.GDAObjects1);
gdjs.copyArray(runtimeScene.getObjects("CollisionDetect"), gdjs.forestCode.GDCollisionDetectObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.forestCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.forestCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.forestCode.GDPlayerObjects1[i].separateFromObjectsList(gdjs.forestCode.mapOfGDgdjs_46forestCode_46GDCollisionDetectObjects1Objects, false);
}
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.forestCode.GDPlayerObjects1.length !== 0 ? gdjs.forestCode.GDPlayerObjects1[0] : null), true, "", 0);
}{for(var i = 0, len = gdjs.forestCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.forestCode.GDPlayerObjects1[i].setZOrder((gdjs.forestCode.GDPlayerObjects1[i].getPointY("")));
}
}{for(var i = 0, len = gdjs.forestCode.GDAObjects1.length ;i < len;++i) {
    gdjs.forestCode.GDAObjects1[i].hide();
}
}}

}


{


gdjs.forestCode.eventsList1(runtimeScene);
}


{


gdjs.forestCode.eventsList5(runtimeScene);
}


{


gdjs.forestCode.eventsList6(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Apple"), gdjs.forestCode.GDAppleObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.forestCode.GDPlayerObjects1);

gdjs.forestCode.condition0IsTrue_0.val = false;
{
gdjs.forestCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.forestCode.mapOfGDgdjs_46forestCode_46GDPlayerObjects1Objects, gdjs.forestCode.mapOfGDgdjs_46forestCode_46GDAppleObjects1Objects, 20, false);
}if (gdjs.forestCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.forestCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CollisionDetect"), gdjs.forestCode.GDCollisionDetectObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.forestCode.GDPlayerObjects1);

gdjs.forestCode.condition0IsTrue_0.val = false;
{
gdjs.forestCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.forestCode.mapOfGDgdjs_46forestCode_46GDPlayerObjects1Objects, gdjs.forestCode.mapOfGDgdjs_46forestCode_46GDCollisionDetectObjects1Objects, 20, false);
}if (gdjs.forestCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.forestCode.eventsList8(runtimeScene);} //End of subevents
}

}


{


gdjs.forestCode.eventsList9(runtimeScene);
}


{


{
gdjs.copyArray(runtimeScene.getObjects("Trees"), gdjs.forestCode.GDTreesObjects1);
{for(var i = 0, len = gdjs.forestCode.GDTreesObjects1.length ;i < len;++i) {
    gdjs.forestCode.GDTreesObjects1[i].setString("Apples: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("tree")));
}
}
{ //Subevents
gdjs.forestCode.eventsList10(runtimeScene);} //End of subevents
}

}


};

gdjs.forestCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.forestCode.GDTransitionObjects1.length = 0;
gdjs.forestCode.GDTransitionObjects2.length = 0;
gdjs.forestCode.GDTransitionObjects3.length = 0;
gdjs.forestCode.GDTransitionObjects4.length = 0;
gdjs.forestCode.GDPlayerObjects1.length = 0;
gdjs.forestCode.GDPlayerObjects2.length = 0;
gdjs.forestCode.GDPlayerObjects3.length = 0;
gdjs.forestCode.GDPlayerObjects4.length = 0;
gdjs.forestCode.GDDock1Objects1.length = 0;
gdjs.forestCode.GDDock1Objects2.length = 0;
gdjs.forestCode.GDDock1Objects3.length = 0;
gdjs.forestCode.GDDock1Objects4.length = 0;
gdjs.forestCode.GDFishermanObjects1.length = 0;
gdjs.forestCode.GDFishermanObjects2.length = 0;
gdjs.forestCode.GDFishermanObjects3.length = 0;
gdjs.forestCode.GDFishermanObjects4.length = 0;
gdjs.forestCode.GDWater1Objects1.length = 0;
gdjs.forestCode.GDWater1Objects2.length = 0;
gdjs.forestCode.GDWater1Objects3.length = 0;
gdjs.forestCode.GDWater1Objects4.length = 0;
gdjs.forestCode.GDTextBorderObjects1.length = 0;
gdjs.forestCode.GDTextBorderObjects2.length = 0;
gdjs.forestCode.GDTextBorderObjects3.length = 0;
gdjs.forestCode.GDTextBorderObjects4.length = 0;
gdjs.forestCode.GDCollisionDetectObjects1.length = 0;
gdjs.forestCode.GDCollisionDetectObjects2.length = 0;
gdjs.forestCode.GDCollisionDetectObjects3.length = 0;
gdjs.forestCode.GDCollisionDetectObjects4.length = 0;
gdjs.forestCode.GDEObjects1.length = 0;
gdjs.forestCode.GDEObjects2.length = 0;
gdjs.forestCode.GDEObjects3.length = 0;
gdjs.forestCode.GDEObjects4.length = 0;
gdjs.forestCode.GDAObjects1.length = 0;
gdjs.forestCode.GDAObjects2.length = 0;
gdjs.forestCode.GDAObjects3.length = 0;
gdjs.forestCode.GDAObjects4.length = 0;
gdjs.forestCode.GDA2Objects1.length = 0;
gdjs.forestCode.GDA2Objects2.length = 0;
gdjs.forestCode.GDA2Objects3.length = 0;
gdjs.forestCode.GDA2Objects4.length = 0;
gdjs.forestCode.GDDialogueObjects1.length = 0;
gdjs.forestCode.GDDialogueObjects2.length = 0;
gdjs.forestCode.GDDialogueObjects3.length = 0;
gdjs.forestCode.GDDialogueObjects4.length = 0;
gdjs.forestCode.GDDialogue4Objects1.length = 0;
gdjs.forestCode.GDDialogue4Objects2.length = 0;
gdjs.forestCode.GDDialogue4Objects3.length = 0;
gdjs.forestCode.GDDialogue4Objects4.length = 0;
gdjs.forestCode.GDYesButtonObjects1.length = 0;
gdjs.forestCode.GDYesButtonObjects2.length = 0;
gdjs.forestCode.GDYesButtonObjects3.length = 0;
gdjs.forestCode.GDYesButtonObjects4.length = 0;
gdjs.forestCode.GDNoButtonObjects1.length = 0;
gdjs.forestCode.GDNoButtonObjects2.length = 0;
gdjs.forestCode.GDNoButtonObjects3.length = 0;
gdjs.forestCode.GDNoButtonObjects4.length = 0;
gdjs.forestCode.GDCornerWaterObjects1.length = 0;
gdjs.forestCode.GDCornerWaterObjects2.length = 0;
gdjs.forestCode.GDCornerWaterObjects3.length = 0;
gdjs.forestCode.GDCornerWaterObjects4.length = 0;
gdjs.forestCode.GDWaterEdgeRightObjects1.length = 0;
gdjs.forestCode.GDWaterEdgeRightObjects2.length = 0;
gdjs.forestCode.GDWaterEdgeRightObjects3.length = 0;
gdjs.forestCode.GDWaterEdgeRightObjects4.length = 0;
gdjs.forestCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.forestCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.forestCode.GDNewTiledSpriteObjects3.length = 0;
gdjs.forestCode.GDNewTiledSpriteObjects4.length = 0;
gdjs.forestCode.GDGrassObjects1.length = 0;
gdjs.forestCode.GDGrassObjects2.length = 0;
gdjs.forestCode.GDGrassObjects3.length = 0;
gdjs.forestCode.GDGrassObjects4.length = 0;
gdjs.forestCode.GDTree2Objects1.length = 0;
gdjs.forestCode.GDTree2Objects2.length = 0;
gdjs.forestCode.GDTree2Objects3.length = 0;
gdjs.forestCode.GDTree2Objects4.length = 0;
gdjs.forestCode.GDNPC2Objects1.length = 0;
gdjs.forestCode.GDNPC2Objects2.length = 0;
gdjs.forestCode.GDNPC2Objects3.length = 0;
gdjs.forestCode.GDNPC2Objects4.length = 0;
gdjs.forestCode.GDBush1Objects1.length = 0;
gdjs.forestCode.GDBush1Objects2.length = 0;
gdjs.forestCode.GDBush1Objects3.length = 0;
gdjs.forestCode.GDBush1Objects4.length = 0;
gdjs.forestCode.GDLakeTroutObjects1.length = 0;
gdjs.forestCode.GDLakeTroutObjects2.length = 0;
gdjs.forestCode.GDLakeTroutObjects3.length = 0;
gdjs.forestCode.GDLakeTroutObjects4.length = 0;
gdjs.forestCode.GDFenceObjects1.length = 0;
gdjs.forestCode.GDFenceObjects2.length = 0;
gdjs.forestCode.GDFenceObjects3.length = 0;
gdjs.forestCode.GDFenceObjects4.length = 0;
gdjs.forestCode.GDfencepostObjects1.length = 0;
gdjs.forestCode.GDfencepostObjects2.length = 0;
gdjs.forestCode.GDfencepostObjects3.length = 0;
gdjs.forestCode.GDfencepostObjects4.length = 0;
gdjs.forestCode.GDTreesObjects1.length = 0;
gdjs.forestCode.GDTreesObjects2.length = 0;
gdjs.forestCode.GDTreesObjects3.length = 0;
gdjs.forestCode.GDTreesObjects4.length = 0;
gdjs.forestCode.GDAppleObjects1.length = 0;
gdjs.forestCode.GDAppleObjects2.length = 0;
gdjs.forestCode.GDAppleObjects3.length = 0;
gdjs.forestCode.GDAppleObjects4.length = 0;

gdjs.forestCode.eventsList11(runtimeScene);

return;

}

gdjs['forestCode'] = gdjs.forestCode;

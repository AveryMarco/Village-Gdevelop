gdjs.FishCode = {};
gdjs.FishCode.GDNoButtonObjects1_1final = [];

gdjs.FishCode.GDYesButtonObjects1_1final = [];

gdjs.FishCode.GDTransitionObjects1= [];
gdjs.FishCode.GDTransitionObjects2= [];
gdjs.FishCode.GDTransitionObjects3= [];
gdjs.FishCode.GDTransitionObjects4= [];
gdjs.FishCode.GDPlayerObjects1= [];
gdjs.FishCode.GDPlayerObjects2= [];
gdjs.FishCode.GDPlayerObjects3= [];
gdjs.FishCode.GDPlayerObjects4= [];
gdjs.FishCode.GDDock1Objects1= [];
gdjs.FishCode.GDDock1Objects2= [];
gdjs.FishCode.GDDock1Objects3= [];
gdjs.FishCode.GDDock1Objects4= [];
gdjs.FishCode.GDFishermanObjects1= [];
gdjs.FishCode.GDFishermanObjects2= [];
gdjs.FishCode.GDFishermanObjects3= [];
gdjs.FishCode.GDFishermanObjects4= [];
gdjs.FishCode.GDWater1Objects1= [];
gdjs.FishCode.GDWater1Objects2= [];
gdjs.FishCode.GDWater1Objects3= [];
gdjs.FishCode.GDWater1Objects4= [];
gdjs.FishCode.GDTextBorderObjects1= [];
gdjs.FishCode.GDTextBorderObjects2= [];
gdjs.FishCode.GDTextBorderObjects3= [];
gdjs.FishCode.GDTextBorderObjects4= [];
gdjs.FishCode.GDCollisionDetectObjects1= [];
gdjs.FishCode.GDCollisionDetectObjects2= [];
gdjs.FishCode.GDCollisionDetectObjects3= [];
gdjs.FishCode.GDCollisionDetectObjects4= [];
gdjs.FishCode.GDEObjects1= [];
gdjs.FishCode.GDEObjects2= [];
gdjs.FishCode.GDEObjects3= [];
gdjs.FishCode.GDEObjects4= [];
gdjs.FishCode.GDAObjects1= [];
gdjs.FishCode.GDAObjects2= [];
gdjs.FishCode.GDAObjects3= [];
gdjs.FishCode.GDAObjects4= [];
gdjs.FishCode.GDA2Objects1= [];
gdjs.FishCode.GDA2Objects2= [];
gdjs.FishCode.GDA2Objects3= [];
gdjs.FishCode.GDA2Objects4= [];
gdjs.FishCode.GDDialogueObjects1= [];
gdjs.FishCode.GDDialogueObjects2= [];
gdjs.FishCode.GDDialogueObjects3= [];
gdjs.FishCode.GDDialogueObjects4= [];
gdjs.FishCode.GDDialogue4Objects1= [];
gdjs.FishCode.GDDialogue4Objects2= [];
gdjs.FishCode.GDDialogue4Objects3= [];
gdjs.FishCode.GDDialogue4Objects4= [];
gdjs.FishCode.GDYesButtonObjects1= [];
gdjs.FishCode.GDYesButtonObjects2= [];
gdjs.FishCode.GDYesButtonObjects3= [];
gdjs.FishCode.GDYesButtonObjects4= [];
gdjs.FishCode.GDNoButtonObjects1= [];
gdjs.FishCode.GDNoButtonObjects2= [];
gdjs.FishCode.GDNoButtonObjects3= [];
gdjs.FishCode.GDNoButtonObjects4= [];
gdjs.FishCode.GDCornerWaterObjects1= [];
gdjs.FishCode.GDCornerWaterObjects2= [];
gdjs.FishCode.GDCornerWaterObjects3= [];
gdjs.FishCode.GDCornerWaterObjects4= [];
gdjs.FishCode.GDWaterEdgeRightObjects1= [];
gdjs.FishCode.GDWaterEdgeRightObjects2= [];
gdjs.FishCode.GDWaterEdgeRightObjects3= [];
gdjs.FishCode.GDWaterEdgeRightObjects4= [];
gdjs.FishCode.GDNewTiledSpriteObjects1= [];
gdjs.FishCode.GDNewTiledSpriteObjects2= [];
gdjs.FishCode.GDNewTiledSpriteObjects3= [];
gdjs.FishCode.GDNewTiledSpriteObjects4= [];
gdjs.FishCode.GDGrassObjects1= [];
gdjs.FishCode.GDGrassObjects2= [];
gdjs.FishCode.GDGrassObjects3= [];
gdjs.FishCode.GDGrassObjects4= [];
gdjs.FishCode.GDTree2Objects1= [];
gdjs.FishCode.GDTree2Objects2= [];
gdjs.FishCode.GDTree2Objects3= [];
gdjs.FishCode.GDTree2Objects4= [];
gdjs.FishCode.GDNPC2Objects1= [];
gdjs.FishCode.GDNPC2Objects2= [];
gdjs.FishCode.GDNPC2Objects3= [];
gdjs.FishCode.GDNPC2Objects4= [];
gdjs.FishCode.GDBush1Objects1= [];
gdjs.FishCode.GDBush1Objects2= [];
gdjs.FishCode.GDBush1Objects3= [];
gdjs.FishCode.GDBush1Objects4= [];
gdjs.FishCode.GDLakeTroutObjects1= [];
gdjs.FishCode.GDLakeTroutObjects2= [];
gdjs.FishCode.GDLakeTroutObjects3= [];
gdjs.FishCode.GDLakeTroutObjects4= [];

gdjs.FishCode.conditionTrue_0 = {val:false};
gdjs.FishCode.condition0IsTrue_0 = {val:false};
gdjs.FishCode.condition1IsTrue_0 = {val:false};
gdjs.FishCode.condition2IsTrue_0 = {val:false};
gdjs.FishCode.conditionTrue_1 = {val:false};
gdjs.FishCode.condition0IsTrue_1 = {val:false};
gdjs.FishCode.condition1IsTrue_1 = {val:false};
gdjs.FishCode.condition2IsTrue_1 = {val:false};


gdjs.FishCode.mapOfGDgdjs_46FishCode_46GDCollisionDetectObjects1Objects = Hashtable.newFrom({"CollisionDetect": gdjs.FishCode.GDCollisionDetectObjects1});
gdjs.FishCode.eventsList0 = function(runtimeScene) {

{


gdjs.FishCode.condition0IsTrue_0.val = false;
{
{gdjs.FishCode.conditionTrue_1 = gdjs.FishCode.condition0IsTrue_0;
gdjs.FishCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15736036);
}
}if (gdjs.FishCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("E"), gdjs.FishCode.GDEObjects2);
gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.FishCode.GDNoButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.FishCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.FishCode.GDYesButtonObjects2);
{for(var i = 0, len = gdjs.FishCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.FishCode.GDPlayerObjects2[i].activateBehavior("TopDownMovement", true);
}
}{for(var i = 0, len = gdjs.FishCode.GDEObjects2.length ;i < len;++i) {
    gdjs.FishCode.GDEObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.FishCode.GDYesButtonObjects2.length ;i < len;++i) {
    gdjs.FishCode.GDYesButtonObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.FishCode.GDNoButtonObjects2.length ;i < len;++i) {
    gdjs.FishCode.GDNoButtonObjects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.FishCode.GDPlayerObjects2);

gdjs.FishCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.FishCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.FishCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isUsingControl("Up") ) {
        gdjs.FishCode.condition0IsTrue_0.val = true;
        gdjs.FishCode.GDPlayerObjects2[k] = gdjs.FishCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.FishCode.GDPlayerObjects2.length = k;}if (gdjs.FishCode.condition0IsTrue_0.val) {
/* Reuse gdjs.FishCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.FishCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.FishCode.GDPlayerObjects2[i].setAnimationName("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.FishCode.GDPlayerObjects2);

gdjs.FishCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.FishCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.FishCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isUsingControl("Down") ) {
        gdjs.FishCode.condition0IsTrue_0.val = true;
        gdjs.FishCode.GDPlayerObjects2[k] = gdjs.FishCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.FishCode.GDPlayerObjects2.length = k;}if (gdjs.FishCode.condition0IsTrue_0.val) {
/* Reuse gdjs.FishCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.FishCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.FishCode.GDPlayerObjects2[i].setAnimationName("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.FishCode.GDPlayerObjects2);

gdjs.FishCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.FishCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.FishCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isUsingControl("Right") ) {
        gdjs.FishCode.condition0IsTrue_0.val = true;
        gdjs.FishCode.GDPlayerObjects2[k] = gdjs.FishCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.FishCode.GDPlayerObjects2.length = k;}if (gdjs.FishCode.condition0IsTrue_0.val) {
/* Reuse gdjs.FishCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.FishCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.FishCode.GDPlayerObjects2[i].setAnimationName("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.FishCode.GDPlayerObjects2);

gdjs.FishCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.FishCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.FishCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isUsingControl("Left") ) {
        gdjs.FishCode.condition0IsTrue_0.val = true;
        gdjs.FishCode.GDPlayerObjects2[k] = gdjs.FishCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.FishCode.GDPlayerObjects2.length = k;}if (gdjs.FishCode.condition0IsTrue_0.val) {
/* Reuse gdjs.FishCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.FishCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.FishCode.GDPlayerObjects2[i].setAnimationName("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.FishCode.GDPlayerObjects2);

gdjs.FishCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.FishCode.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.FishCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isMoving()) ) {
        gdjs.FishCode.condition0IsTrue_0.val = true;
        gdjs.FishCode.GDPlayerObjects2[k] = gdjs.FishCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.FishCode.GDPlayerObjects2.length = k;}if (gdjs.FishCode.condition0IsTrue_0.val) {
/* Reuse gdjs.FishCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.FishCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.FishCode.GDPlayerObjects2[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.FishCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.FishCode.GDPlayerObjects2[i].setAnimationFrame(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.FishCode.GDPlayerObjects1);

gdjs.FishCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.FishCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.FishCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").isMoving() ) {
        gdjs.FishCode.condition0IsTrue_0.val = true;
        gdjs.FishCode.GDPlayerObjects1[k] = gdjs.FishCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.FishCode.GDPlayerObjects1.length = k;}if (gdjs.FishCode.condition0IsTrue_0.val) {
/* Reuse gdjs.FishCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.FishCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.FishCode.GDPlayerObjects1[i].playAnimation();
}
}}

}


};gdjs.FishCode.eventsList1 = function(runtimeScene) {

{


gdjs.FishCode.condition0IsTrue_0.val = false;
{
gdjs.FishCode.condition0IsTrue_0.val = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Dialogue"));
}if (gdjs.FishCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.FishCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.FishCode.mapOfGDgdjs_46FishCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.FishCode.GDPlayerObjects2});
gdjs.FishCode.mapOfGDgdjs_46FishCode_46GDFishermanObjects2Objects = Hashtable.newFrom({"Fisherman": gdjs.FishCode.GDFishermanObjects2});
gdjs.FishCode.eventsList2 = function(runtimeScene) {

{


gdjs.FishCode.condition0IsTrue_0.val = false;
gdjs.FishCode.condition1IsTrue_0.val = false;
{
gdjs.FishCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.FishCode.condition0IsTrue_0.val ) {
{
{gdjs.FishCode.conditionTrue_1 = gdjs.FishCode.condition1IsTrue_0;
gdjs.FishCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15742500);
}
}}
if (gdjs.FishCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("E"), gdjs.FishCode.GDEObjects2);
{gdjs.evtTools.camera.showLayer(runtimeScene, "Dialogue");
}{for(var i = 0, len = gdjs.FishCode.GDEObjects2.length ;i < len;++i) {
    gdjs.FishCode.GDEObjects2[i].hide();
}
}}

}


};gdjs.FishCode.asyncCallback15747956 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Fishing");
}}
gdjs.FishCode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.FishCode.asyncCallback15747956(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.FishCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.FishCode.GDYesButtonObjects2, gdjs.FishCode.GDYesButtonObjects3);


gdjs.FishCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.FishCode.GDYesButtonObjects3.length;i<l;++i) {
    if ( gdjs.FishCode.GDYesButtonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.FishCode.condition0IsTrue_0.val = true;
        gdjs.FishCode.GDYesButtonObjects3[k] = gdjs.FishCode.GDYesButtonObjects3[i];
        ++k;
    }
}
gdjs.FishCode.GDYesButtonObjects3.length = k;}if (gdjs.FishCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Transition"), gdjs.FishCode.GDTransitionObjects3);
{for(var i = 0, len = gdjs.FishCode.GDTransitionObjects3.length ;i < len;++i) {
    gdjs.FishCode.GDTransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 1, "Circular", "Forward", 255, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.FishCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.FishCode.GDNoButtonObjects2);

gdjs.FishCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.FishCode.GDNoButtonObjects2.length;i<l;++i) {
    if ( gdjs.FishCode.GDNoButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.FishCode.condition0IsTrue_0.val = true;
        gdjs.FishCode.GDNoButtonObjects2[k] = gdjs.FishCode.GDNoButtonObjects2[i];
        ++k;
    }
}
gdjs.FishCode.GDNoButtonObjects2.length = k;}if (gdjs.FishCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Dialogue");
}{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


};gdjs.FishCode.eventsList5 = function(runtimeScene) {

{


gdjs.FishCode.condition0IsTrue_0.val = false;
{
{gdjs.FishCode.conditionTrue_1 = gdjs.FishCode.condition0IsTrue_0;
gdjs.FishCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15743516);
}
}if (gdjs.FishCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.FishCode.GDDialogueObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.FishCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.FishCode.GDDialogueObjects2.length ;i < len;++i) {
    gdjs.FishCode.GDDialogueObjects2[i].getBehavior("BitmapText_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.FishCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.FishCode.GDPlayerObjects2[i].activateBehavior("TopDownMovement", false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Talk.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.FishCode.GDDialogueObjects2);

gdjs.FishCode.condition0IsTrue_0.val = false;
gdjs.FishCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.FishCode.GDDialogueObjects2.length;i<l;++i) {
    if ( gdjs.FishCode.GDDialogueObjects2[i].getBehavior("BitmapText_AutoTyping").TypingFinished((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.FishCode.condition0IsTrue_0.val = true;
        gdjs.FishCode.GDDialogueObjects2[k] = gdjs.FishCode.GDDialogueObjects2[i];
        ++k;
    }
}
gdjs.FishCode.GDDialogueObjects2.length = k;}if ( gdjs.FishCode.condition0IsTrue_0.val ) {
{
{gdjs.FishCode.conditionTrue_1 = gdjs.FishCode.condition1IsTrue_0;
gdjs.FishCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15745756);
}
}}
if (gdjs.FishCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.FishCode.GDNoButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.FishCode.GDYesButtonObjects2);
{for(var i = 0, len = gdjs.FishCode.GDYesButtonObjects2.length ;i < len;++i) {
    gdjs.FishCode.GDYesButtonObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.FishCode.GDNoButtonObjects2.length ;i < len;++i) {
    gdjs.FishCode.GDNoButtonObjects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.FishCode.GDYesButtonObjects2);

gdjs.FishCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.FishCode.GDYesButtonObjects2.length;i<l;++i) {
    if ( gdjs.FishCode.GDYesButtonObjects2[i].isVisible() ) {
        gdjs.FishCode.condition0IsTrue_0.val = true;
        gdjs.FishCode.GDYesButtonObjects2[k] = gdjs.FishCode.GDYesButtonObjects2[i];
        ++k;
    }
}
gdjs.FishCode.GDYesButtonObjects2.length = k;}if (gdjs.FishCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.FishCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.FishCode.GDNoButtonObjects1.length = 0;

gdjs.FishCode.GDYesButtonObjects1.length = 0;


gdjs.FishCode.condition0IsTrue_0.val = false;
gdjs.FishCode.condition1IsTrue_0.val = false;
{
{gdjs.FishCode.conditionTrue_1 = gdjs.FishCode.condition0IsTrue_0;
gdjs.FishCode.GDNoButtonObjects1_1final.length = 0;gdjs.FishCode.GDYesButtonObjects1_1final.length = 0;gdjs.FishCode.condition0IsTrue_1.val = false;
gdjs.FishCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.FishCode.GDNoButtonObjects2);
for(var i = 0, k = 0, l = gdjs.FishCode.GDNoButtonObjects2.length;i<l;++i) {
    if ( gdjs.FishCode.GDNoButtonObjects2[i].IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.FishCode.condition0IsTrue_1.val = true;
        gdjs.FishCode.GDNoButtonObjects2[k] = gdjs.FishCode.GDNoButtonObjects2[i];
        ++k;
    }
}
gdjs.FishCode.GDNoButtonObjects2.length = k;if( gdjs.FishCode.condition0IsTrue_1.val ) {
    gdjs.FishCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.FishCode.GDNoButtonObjects2.length;j<jLen;++j) {
        if ( gdjs.FishCode.GDNoButtonObjects1_1final.indexOf(gdjs.FishCode.GDNoButtonObjects2[j]) === -1 )
            gdjs.FishCode.GDNoButtonObjects1_1final.push(gdjs.FishCode.GDNoButtonObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.FishCode.GDYesButtonObjects2);
for(var i = 0, k = 0, l = gdjs.FishCode.GDYesButtonObjects2.length;i<l;++i) {
    if ( gdjs.FishCode.GDYesButtonObjects2[i].IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.FishCode.condition1IsTrue_1.val = true;
        gdjs.FishCode.GDYesButtonObjects2[k] = gdjs.FishCode.GDYesButtonObjects2[i];
        ++k;
    }
}
gdjs.FishCode.GDYesButtonObjects2.length = k;if( gdjs.FishCode.condition1IsTrue_1.val ) {
    gdjs.FishCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.FishCode.GDYesButtonObjects2.length;j<jLen;++j) {
        if ( gdjs.FishCode.GDYesButtonObjects1_1final.indexOf(gdjs.FishCode.GDYesButtonObjects2[j]) === -1 )
            gdjs.FishCode.GDYesButtonObjects1_1final.push(gdjs.FishCode.GDYesButtonObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.FishCode.GDNoButtonObjects1_1final, gdjs.FishCode.GDNoButtonObjects1);
gdjs.copyArray(gdjs.FishCode.GDYesButtonObjects1_1final, gdjs.FishCode.GDYesButtonObjects1);
}
}
}if ( gdjs.FishCode.condition0IsTrue_0.val ) {
{
{gdjs.FishCode.conditionTrue_1 = gdjs.FishCode.condition1IsTrue_0;
gdjs.FishCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15750684);
}
}}
if (gdjs.FishCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "HoverSound.wav", false, 20, gdjs.randomFloatInRange(0.8, 0.9));
}}

}


};gdjs.FishCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Fisherman"), gdjs.FishCode.GDFishermanObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.FishCode.GDPlayerObjects2);

gdjs.FishCode.condition0IsTrue_0.val = false;
{
gdjs.FishCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.FishCode.mapOfGDgdjs_46FishCode_46GDPlayerObjects2Objects, gdjs.FishCode.mapOfGDgdjs_46FishCode_46GDFishermanObjects2Objects, 20, false);
}if (gdjs.FishCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.FishCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


gdjs.FishCode.condition0IsTrue_0.val = false;
{
gdjs.FishCode.condition0IsTrue_0.val = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Dialogue");
}if (gdjs.FishCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.FishCode.eventsList5(runtimeScene);} //End of subevents
}

}


};gdjs.FishCode.eventsList7 = function(runtimeScene) {

};gdjs.FishCode.eventsList8 = function(runtimeScene) {

{


gdjs.FishCode.condition0IsTrue_0.val = false;
{
gdjs.FishCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.FishCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CollisionDetect"), gdjs.FishCode.GDCollisionDetectObjects1);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 6, "", 0);
}{for(var i = 0, len = gdjs.FishCode.GDCollisionDetectObjects1.length ;i < len;++i) {
    gdjs.FishCode.GDCollisionDetectObjects1[i].hide();
}
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1.5, "Transition", 0);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("CollisionDetect"), gdjs.FishCode.GDCollisionDetectObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.FishCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.FishCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.FishCode.GDPlayerObjects1[i].separateFromObjectsList(gdjs.FishCode.mapOfGDgdjs_46FishCode_46GDCollisionDetectObjects1Objects, false);
}
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.FishCode.GDPlayerObjects1.length !== 0 ? gdjs.FishCode.GDPlayerObjects1[0] : null), true, "", 0);
}{for(var i = 0, len = gdjs.FishCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.FishCode.GDPlayerObjects1[i].setZOrder((gdjs.FishCode.GDPlayerObjects1[i].getPointY("")));
}
}}

}


{


gdjs.FishCode.eventsList1(runtimeScene);
}


{


gdjs.FishCode.eventsList6(runtimeScene);
}


{


gdjs.FishCode.eventsList7(runtimeScene);
}


};

gdjs.FishCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.FishCode.GDTransitionObjects1.length = 0;
gdjs.FishCode.GDTransitionObjects2.length = 0;
gdjs.FishCode.GDTransitionObjects3.length = 0;
gdjs.FishCode.GDTransitionObjects4.length = 0;
gdjs.FishCode.GDPlayerObjects1.length = 0;
gdjs.FishCode.GDPlayerObjects2.length = 0;
gdjs.FishCode.GDPlayerObjects3.length = 0;
gdjs.FishCode.GDPlayerObjects4.length = 0;
gdjs.FishCode.GDDock1Objects1.length = 0;
gdjs.FishCode.GDDock1Objects2.length = 0;
gdjs.FishCode.GDDock1Objects3.length = 0;
gdjs.FishCode.GDDock1Objects4.length = 0;
gdjs.FishCode.GDFishermanObjects1.length = 0;
gdjs.FishCode.GDFishermanObjects2.length = 0;
gdjs.FishCode.GDFishermanObjects3.length = 0;
gdjs.FishCode.GDFishermanObjects4.length = 0;
gdjs.FishCode.GDWater1Objects1.length = 0;
gdjs.FishCode.GDWater1Objects2.length = 0;
gdjs.FishCode.GDWater1Objects3.length = 0;
gdjs.FishCode.GDWater1Objects4.length = 0;
gdjs.FishCode.GDTextBorderObjects1.length = 0;
gdjs.FishCode.GDTextBorderObjects2.length = 0;
gdjs.FishCode.GDTextBorderObjects3.length = 0;
gdjs.FishCode.GDTextBorderObjects4.length = 0;
gdjs.FishCode.GDCollisionDetectObjects1.length = 0;
gdjs.FishCode.GDCollisionDetectObjects2.length = 0;
gdjs.FishCode.GDCollisionDetectObjects3.length = 0;
gdjs.FishCode.GDCollisionDetectObjects4.length = 0;
gdjs.FishCode.GDEObjects1.length = 0;
gdjs.FishCode.GDEObjects2.length = 0;
gdjs.FishCode.GDEObjects3.length = 0;
gdjs.FishCode.GDEObjects4.length = 0;
gdjs.FishCode.GDAObjects1.length = 0;
gdjs.FishCode.GDAObjects2.length = 0;
gdjs.FishCode.GDAObjects3.length = 0;
gdjs.FishCode.GDAObjects4.length = 0;
gdjs.FishCode.GDA2Objects1.length = 0;
gdjs.FishCode.GDA2Objects2.length = 0;
gdjs.FishCode.GDA2Objects3.length = 0;
gdjs.FishCode.GDA2Objects4.length = 0;
gdjs.FishCode.GDDialogueObjects1.length = 0;
gdjs.FishCode.GDDialogueObjects2.length = 0;
gdjs.FishCode.GDDialogueObjects3.length = 0;
gdjs.FishCode.GDDialogueObjects4.length = 0;
gdjs.FishCode.GDDialogue4Objects1.length = 0;
gdjs.FishCode.GDDialogue4Objects2.length = 0;
gdjs.FishCode.GDDialogue4Objects3.length = 0;
gdjs.FishCode.GDDialogue4Objects4.length = 0;
gdjs.FishCode.GDYesButtonObjects1.length = 0;
gdjs.FishCode.GDYesButtonObjects2.length = 0;
gdjs.FishCode.GDYesButtonObjects3.length = 0;
gdjs.FishCode.GDYesButtonObjects4.length = 0;
gdjs.FishCode.GDNoButtonObjects1.length = 0;
gdjs.FishCode.GDNoButtonObjects2.length = 0;
gdjs.FishCode.GDNoButtonObjects3.length = 0;
gdjs.FishCode.GDNoButtonObjects4.length = 0;
gdjs.FishCode.GDCornerWaterObjects1.length = 0;
gdjs.FishCode.GDCornerWaterObjects2.length = 0;
gdjs.FishCode.GDCornerWaterObjects3.length = 0;
gdjs.FishCode.GDCornerWaterObjects4.length = 0;
gdjs.FishCode.GDWaterEdgeRightObjects1.length = 0;
gdjs.FishCode.GDWaterEdgeRightObjects2.length = 0;
gdjs.FishCode.GDWaterEdgeRightObjects3.length = 0;
gdjs.FishCode.GDWaterEdgeRightObjects4.length = 0;
gdjs.FishCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.FishCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.FishCode.GDNewTiledSpriteObjects3.length = 0;
gdjs.FishCode.GDNewTiledSpriteObjects4.length = 0;
gdjs.FishCode.GDGrassObjects1.length = 0;
gdjs.FishCode.GDGrassObjects2.length = 0;
gdjs.FishCode.GDGrassObjects3.length = 0;
gdjs.FishCode.GDGrassObjects4.length = 0;
gdjs.FishCode.GDTree2Objects1.length = 0;
gdjs.FishCode.GDTree2Objects2.length = 0;
gdjs.FishCode.GDTree2Objects3.length = 0;
gdjs.FishCode.GDTree2Objects4.length = 0;
gdjs.FishCode.GDNPC2Objects1.length = 0;
gdjs.FishCode.GDNPC2Objects2.length = 0;
gdjs.FishCode.GDNPC2Objects3.length = 0;
gdjs.FishCode.GDNPC2Objects4.length = 0;
gdjs.FishCode.GDBush1Objects1.length = 0;
gdjs.FishCode.GDBush1Objects2.length = 0;
gdjs.FishCode.GDBush1Objects3.length = 0;
gdjs.FishCode.GDBush1Objects4.length = 0;
gdjs.FishCode.GDLakeTroutObjects1.length = 0;
gdjs.FishCode.GDLakeTroutObjects2.length = 0;
gdjs.FishCode.GDLakeTroutObjects3.length = 0;
gdjs.FishCode.GDLakeTroutObjects4.length = 0;

gdjs.FishCode.eventsList8(runtimeScene);

return;

}

gdjs['FishCode'] = gdjs.FishCode;

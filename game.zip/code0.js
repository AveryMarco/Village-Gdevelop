gdjs.OverworldCode = {};
gdjs.OverworldCode.GDNoButtonObjects1_1final = [];

gdjs.OverworldCode.GDYesButtonObjects1_1final = [];

gdjs.OverworldCode.GDTransitionObjects1= [];
gdjs.OverworldCode.GDTransitionObjects2= [];
gdjs.OverworldCode.GDTransitionObjects3= [];
gdjs.OverworldCode.GDTransitionObjects4= [];
gdjs.OverworldCode.GDPlayerObjects1= [];
gdjs.OverworldCode.GDPlayerObjects2= [];
gdjs.OverworldCode.GDPlayerObjects3= [];
gdjs.OverworldCode.GDPlayerObjects4= [];
gdjs.OverworldCode.GDDock1Objects1= [];
gdjs.OverworldCode.GDDock1Objects2= [];
gdjs.OverworldCode.GDDock1Objects3= [];
gdjs.OverworldCode.GDDock1Objects4= [];
gdjs.OverworldCode.GDFishermanObjects1= [];
gdjs.OverworldCode.GDFishermanObjects2= [];
gdjs.OverworldCode.GDFishermanObjects3= [];
gdjs.OverworldCode.GDFishermanObjects4= [];
gdjs.OverworldCode.GDWater1Objects1= [];
gdjs.OverworldCode.GDWater1Objects2= [];
gdjs.OverworldCode.GDWater1Objects3= [];
gdjs.OverworldCode.GDWater1Objects4= [];
gdjs.OverworldCode.GDTextBorderObjects1= [];
gdjs.OverworldCode.GDTextBorderObjects2= [];
gdjs.OverworldCode.GDTextBorderObjects3= [];
gdjs.OverworldCode.GDTextBorderObjects4= [];
gdjs.OverworldCode.GDCollisionDetectObjects1= [];
gdjs.OverworldCode.GDCollisionDetectObjects2= [];
gdjs.OverworldCode.GDCollisionDetectObjects3= [];
gdjs.OverworldCode.GDCollisionDetectObjects4= [];
gdjs.OverworldCode.GDEObjects1= [];
gdjs.OverworldCode.GDEObjects2= [];
gdjs.OverworldCode.GDEObjects3= [];
gdjs.OverworldCode.GDEObjects4= [];
gdjs.OverworldCode.GDAObjects1= [];
gdjs.OverworldCode.GDAObjects2= [];
gdjs.OverworldCode.GDAObjects3= [];
gdjs.OverworldCode.GDAObjects4= [];
gdjs.OverworldCode.GDA2Objects1= [];
gdjs.OverworldCode.GDA2Objects2= [];
gdjs.OverworldCode.GDA2Objects3= [];
gdjs.OverworldCode.GDA2Objects4= [];
gdjs.OverworldCode.GDDialogueObjects1= [];
gdjs.OverworldCode.GDDialogueObjects2= [];
gdjs.OverworldCode.GDDialogueObjects3= [];
gdjs.OverworldCode.GDDialogueObjects4= [];
gdjs.OverworldCode.GDDialogue4Objects1= [];
gdjs.OverworldCode.GDDialogue4Objects2= [];
gdjs.OverworldCode.GDDialogue4Objects3= [];
gdjs.OverworldCode.GDDialogue4Objects4= [];
gdjs.OverworldCode.GDYesButtonObjects1= [];
gdjs.OverworldCode.GDYesButtonObjects2= [];
gdjs.OverworldCode.GDYesButtonObjects3= [];
gdjs.OverworldCode.GDYesButtonObjects4= [];
gdjs.OverworldCode.GDNoButtonObjects1= [];
gdjs.OverworldCode.GDNoButtonObjects2= [];
gdjs.OverworldCode.GDNoButtonObjects3= [];
gdjs.OverworldCode.GDNoButtonObjects4= [];
gdjs.OverworldCode.GDCornerWaterObjects1= [];
gdjs.OverworldCode.GDCornerWaterObjects2= [];
gdjs.OverworldCode.GDCornerWaterObjects3= [];
gdjs.OverworldCode.GDCornerWaterObjects4= [];
gdjs.OverworldCode.GDWaterEdgeRightObjects1= [];
gdjs.OverworldCode.GDWaterEdgeRightObjects2= [];
gdjs.OverworldCode.GDWaterEdgeRightObjects3= [];
gdjs.OverworldCode.GDWaterEdgeRightObjects4= [];
gdjs.OverworldCode.GDNewTiledSpriteObjects1= [];
gdjs.OverworldCode.GDNewTiledSpriteObjects2= [];
gdjs.OverworldCode.GDNewTiledSpriteObjects3= [];
gdjs.OverworldCode.GDNewTiledSpriteObjects4= [];
gdjs.OverworldCode.GDGrassObjects1= [];
gdjs.OverworldCode.GDGrassObjects2= [];
gdjs.OverworldCode.GDGrassObjects3= [];
gdjs.OverworldCode.GDGrassObjects4= [];
gdjs.OverworldCode.GDTree2Objects1= [];
gdjs.OverworldCode.GDTree2Objects2= [];
gdjs.OverworldCode.GDTree2Objects3= [];
gdjs.OverworldCode.GDTree2Objects4= [];
gdjs.OverworldCode.GDNPC2Objects1= [];
gdjs.OverworldCode.GDNPC2Objects2= [];
gdjs.OverworldCode.GDNPC2Objects3= [];
gdjs.OverworldCode.GDNPC2Objects4= [];
gdjs.OverworldCode.GDBush1Objects1= [];
gdjs.OverworldCode.GDBush1Objects2= [];
gdjs.OverworldCode.GDBush1Objects3= [];
gdjs.OverworldCode.GDBush1Objects4= [];
gdjs.OverworldCode.GDLakeTroutObjects1= [];
gdjs.OverworldCode.GDLakeTroutObjects2= [];
gdjs.OverworldCode.GDLakeTroutObjects3= [];
gdjs.OverworldCode.GDLakeTroutObjects4= [];
gdjs.OverworldCode.GDPlayerObjects1= [];
gdjs.OverworldCode.GDPlayerObjects2= [];
gdjs.OverworldCode.GDPlayerObjects3= [];
gdjs.OverworldCode.GDPlayerObjects4= [];
gdjs.OverworldCode.GDNPCObjects1= [];
gdjs.OverworldCode.GDNPCObjects2= [];
gdjs.OverworldCode.GDNPCObjects3= [];
gdjs.OverworldCode.GDNPCObjects4= [];
gdjs.OverworldCode.GDNPC2Objects1= [];
gdjs.OverworldCode.GDNPC2Objects2= [];
gdjs.OverworldCode.GDNPC2Objects3= [];
gdjs.OverworldCode.GDNPC2Objects4= [];
gdjs.OverworldCode.GDDock1Objects1= [];
gdjs.OverworldCode.GDDock1Objects2= [];
gdjs.OverworldCode.GDDock1Objects3= [];
gdjs.OverworldCode.GDDock1Objects4= [];
gdjs.OverworldCode.GDTree1Objects1= [];
gdjs.OverworldCode.GDTree1Objects2= [];
gdjs.OverworldCode.GDTree1Objects3= [];
gdjs.OverworldCode.GDTree1Objects4= [];
gdjs.OverworldCode.GDTree2Objects1= [];
gdjs.OverworldCode.GDTree2Objects2= [];
gdjs.OverworldCode.GDTree2Objects3= [];
gdjs.OverworldCode.GDTree2Objects4= [];
gdjs.OverworldCode.GDBush1Objects1= [];
gdjs.OverworldCode.GDBush1Objects2= [];
gdjs.OverworldCode.GDBush1Objects3= [];
gdjs.OverworldCode.GDBush1Objects4= [];
gdjs.OverworldCode.GDHouse1Objects1= [];
gdjs.OverworldCode.GDHouse1Objects2= [];
gdjs.OverworldCode.GDHouse1Objects3= [];
gdjs.OverworldCode.GDHouse1Objects4= [];
gdjs.OverworldCode.GDHouse2Objects1= [];
gdjs.OverworldCode.GDHouse2Objects2= [];
gdjs.OverworldCode.GDHouse2Objects3= [];
gdjs.OverworldCode.GDHouse2Objects4= [];
gdjs.OverworldCode.GDCornerWaterObjects1= [];
gdjs.OverworldCode.GDCornerWaterObjects2= [];
gdjs.OverworldCode.GDCornerWaterObjects3= [];
gdjs.OverworldCode.GDCornerWaterObjects4= [];
gdjs.OverworldCode.GDWaterCorner2Objects1= [];
gdjs.OverworldCode.GDWaterCorner2Objects2= [];
gdjs.OverworldCode.GDWaterCorner2Objects3= [];
gdjs.OverworldCode.GDWaterCorner2Objects4= [];
gdjs.OverworldCode.GDGrassObjects1= [];
gdjs.OverworldCode.GDGrassObjects2= [];
gdjs.OverworldCode.GDGrassObjects3= [];
gdjs.OverworldCode.GDGrassObjects4= [];
gdjs.OverworldCode.GDWaterEdgeRightObjects1= [];
gdjs.OverworldCode.GDWaterEdgeRightObjects2= [];
gdjs.OverworldCode.GDWaterEdgeRightObjects3= [];
gdjs.OverworldCode.GDWaterEdgeRightObjects4= [];
gdjs.OverworldCode.GDNewTiledSpriteObjects1= [];
gdjs.OverworldCode.GDNewTiledSpriteObjects2= [];
gdjs.OverworldCode.GDNewTiledSpriteObjects3= [];
gdjs.OverworldCode.GDNewTiledSpriteObjects4= [];
gdjs.OverworldCode.GDWater1Objects1= [];
gdjs.OverworldCode.GDWater1Objects2= [];
gdjs.OverworldCode.GDWater1Objects3= [];
gdjs.OverworldCode.GDWater1Objects4= [];
gdjs.OverworldCode.GDRoad1Objects1= [];
gdjs.OverworldCode.GDRoad1Objects2= [];
gdjs.OverworldCode.GDRoad1Objects3= [];
gdjs.OverworldCode.GDRoad1Objects4= [];
gdjs.OverworldCode.GDRoadEdge1Objects1= [];
gdjs.OverworldCode.GDRoadEdge1Objects2= [];
gdjs.OverworldCode.GDRoadEdge1Objects3= [];
gdjs.OverworldCode.GDRoadEdge1Objects4= [];
gdjs.OverworldCode.GDCollisionDetectObjects1= [];
gdjs.OverworldCode.GDCollisionDetectObjects2= [];
gdjs.OverworldCode.GDCollisionDetectObjects3= [];
gdjs.OverworldCode.GDCollisionDetectObjects4= [];
gdjs.OverworldCode.GDDialogueObjects1= [];
gdjs.OverworldCode.GDDialogueObjects2= [];
gdjs.OverworldCode.GDDialogueObjects3= [];
gdjs.OverworldCode.GDDialogueObjects4= [];
gdjs.OverworldCode.GDDialogue2Objects1= [];
gdjs.OverworldCode.GDDialogue2Objects2= [];
gdjs.OverworldCode.GDDialogue2Objects3= [];
gdjs.OverworldCode.GDDialogue2Objects4= [];
gdjs.OverworldCode.GDDialogue3Objects1= [];
gdjs.OverworldCode.GDDialogue3Objects2= [];
gdjs.OverworldCode.GDDialogue3Objects3= [];
gdjs.OverworldCode.GDDialogue3Objects4= [];
gdjs.OverworldCode.GDEObjects1= [];
gdjs.OverworldCode.GDEObjects2= [];
gdjs.OverworldCode.GDEObjects3= [];
gdjs.OverworldCode.GDEObjects4= [];
gdjs.OverworldCode.GDE3Objects1= [];
gdjs.OverworldCode.GDE3Objects2= [];
gdjs.OverworldCode.GDE3Objects3= [];
gdjs.OverworldCode.GDE3Objects4= [];
gdjs.OverworldCode.GDE2Objects1= [];
gdjs.OverworldCode.GDE2Objects2= [];
gdjs.OverworldCode.GDE2Objects3= [];
gdjs.OverworldCode.GDE2Objects4= [];
gdjs.OverworldCode.GDYesButtonObjects1= [];
gdjs.OverworldCode.GDYesButtonObjects2= [];
gdjs.OverworldCode.GDYesButtonObjects3= [];
gdjs.OverworldCode.GDYesButtonObjects4= [];
gdjs.OverworldCode.GDNoButtonObjects1= [];
gdjs.OverworldCode.GDNoButtonObjects2= [];
gdjs.OverworldCode.GDNoButtonObjects3= [];
gdjs.OverworldCode.GDNoButtonObjects4= [];
gdjs.OverworldCode.GDChiChiTheBirdObjects1= [];
gdjs.OverworldCode.GDChiChiTheBirdObjects2= [];
gdjs.OverworldCode.GDChiChiTheBirdObjects3= [];
gdjs.OverworldCode.GDChiChiTheBirdObjects4= [];
gdjs.OverworldCode.GDFishermanObjects1= [];
gdjs.OverworldCode.GDFishermanObjects2= [];
gdjs.OverworldCode.GDFishermanObjects3= [];
gdjs.OverworldCode.GDFishermanObjects4= [];
gdjs.OverworldCode.GDTasksObjects1= [];
gdjs.OverworldCode.GDTasksObjects2= [];
gdjs.OverworldCode.GDTasksObjects3= [];
gdjs.OverworldCode.GDTasksObjects4= [];
gdjs.OverworldCode.GDRedFlowerObjects1= [];
gdjs.OverworldCode.GDRedFlowerObjects2= [];
gdjs.OverworldCode.GDRedFlowerObjects3= [];
gdjs.OverworldCode.GDRedFlowerObjects4= [];
gdjs.OverworldCode.GDLakeTroutObjects1= [];
gdjs.OverworldCode.GDLakeTroutObjects2= [];
gdjs.OverworldCode.GDLakeTroutObjects3= [];
gdjs.OverworldCode.GDLakeTroutObjects4= [];
gdjs.OverworldCode.GDFenceObjects1= [];
gdjs.OverworldCode.GDFenceObjects2= [];
gdjs.OverworldCode.GDFenceObjects3= [];
gdjs.OverworldCode.GDFenceObjects4= [];
gdjs.OverworldCode.GDfencepostObjects1= [];
gdjs.OverworldCode.GDfencepostObjects2= [];
gdjs.OverworldCode.GDfencepostObjects3= [];
gdjs.OverworldCode.GDfencepostObjects4= [];
gdjs.OverworldCode.GDMaleCharacter8Objects1= [];
gdjs.OverworldCode.GDMaleCharacter8Objects2= [];
gdjs.OverworldCode.GDMaleCharacter8Objects3= [];
gdjs.OverworldCode.GDMaleCharacter8Objects4= [];
gdjs.OverworldCode.GDBrownBackgroundObjects1= [];
gdjs.OverworldCode.GDBrownBackgroundObjects2= [];
gdjs.OverworldCode.GDBrownBackgroundObjects3= [];
gdjs.OverworldCode.GDBrownBackgroundObjects4= [];
gdjs.OverworldCode.GDNewSpriteObjects1= [];
gdjs.OverworldCode.GDNewSpriteObjects2= [];
gdjs.OverworldCode.GDNewSpriteObjects3= [];
gdjs.OverworldCode.GDNewSpriteObjects4= [];
gdjs.OverworldCode.GDNewSprite2Objects1= [];
gdjs.OverworldCode.GDNewSprite2Objects2= [];
gdjs.OverworldCode.GDNewSprite2Objects3= [];
gdjs.OverworldCode.GDNewSprite2Objects4= [];
gdjs.OverworldCode.GDNewSprite3Objects1= [];
gdjs.OverworldCode.GDNewSprite3Objects2= [];
gdjs.OverworldCode.GDNewSprite3Objects3= [];
gdjs.OverworldCode.GDNewSprite3Objects4= [];
gdjs.OverworldCode.GDCowObjects1= [];
gdjs.OverworldCode.GDCowObjects2= [];
gdjs.OverworldCode.GDCowObjects3= [];
gdjs.OverworldCode.GDCowObjects4= [];
gdjs.OverworldCode.GDBrownHorseObjects1= [];
gdjs.OverworldCode.GDBrownHorseObjects2= [];
gdjs.OverworldCode.GDBrownHorseObjects3= [];
gdjs.OverworldCode.GDBrownHorseObjects4= [];

gdjs.OverworldCode.conditionTrue_0 = {val:false};
gdjs.OverworldCode.condition0IsTrue_0 = {val:false};
gdjs.OverworldCode.condition1IsTrue_0 = {val:false};
gdjs.OverworldCode.condition2IsTrue_0 = {val:false};
gdjs.OverworldCode.conditionTrue_1 = {val:false};
gdjs.OverworldCode.condition0IsTrue_1 = {val:false};
gdjs.OverworldCode.condition1IsTrue_1 = {val:false};
gdjs.OverworldCode.condition2IsTrue_1 = {val:false};


gdjs.OverworldCode.mapOfGDgdjs_46OverworldCode_46GDCollisionDetectObjects1Objects = Hashtable.newFrom({"CollisionDetect": gdjs.OverworldCode.GDCollisionDetectObjects1});
gdjs.OverworldCode.eventsList0 = function(runtimeScene) {

{


gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
{gdjs.OverworldCode.conditionTrue_1 = gdjs.OverworldCode.condition0IsTrue_0;
gdjs.OverworldCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15534404);
}
}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("E"), gdjs.OverworldCode.GDEObjects3);
gdjs.copyArray(runtimeScene.getObjects("E3"), gdjs.OverworldCode.GDE3Objects3);
gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.OverworldCode.GDNoButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.OverworldCode.GDYesButtonObjects3);
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects3[i].activateBehavior("TopDownMovement", true);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDEObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDEObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDE3Objects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDE3Objects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDYesButtonObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDYesButtonObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDNoButtonObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDNoButtonObjects3[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects3);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").isUsingControl("Up") ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDPlayerObjects3[k] = gdjs.OverworldCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects3.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects3[i].setAnimationName("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects3);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").isUsingControl("Down") ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDPlayerObjects3[k] = gdjs.OverworldCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects3.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects3[i].setAnimationName("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects3);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").isUsingControl("Right") ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDPlayerObjects3[k] = gdjs.OverworldCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects3.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects3[i].setAnimationName("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects3);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").isUsingControl("Left") ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDPlayerObjects3[k] = gdjs.OverworldCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects3.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects3[i].setAnimationName("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects3);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.OverworldCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").isMoving()) ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDPlayerObjects3[k] = gdjs.OverworldCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects3.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects3[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects3[i].setAnimationFrame(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects2);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isMoving() ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDPlayerObjects2[k] = gdjs.OverworldCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects2.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects2[i].playAnimation();
}
}}

}


};gdjs.OverworldCode.eventsList1 = function(runtimeScene) {

{


gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
{gdjs.OverworldCode.conditionTrue_1 = gdjs.OverworldCode.condition0IsTrue_0;
gdjs.OverworldCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15541068);
}
}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("E"), gdjs.OverworldCode.GDEObjects3);
gdjs.copyArray(runtimeScene.getObjects("E3"), gdjs.OverworldCode.GDE3Objects3);
gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.OverworldCode.GDNoButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.OverworldCode.GDYesButtonObjects3);
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects3[i].activateBehavior("TopDownMovement", true);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDEObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDEObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDE3Objects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDE3Objects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDYesButtonObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDYesButtonObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDNoButtonObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDNoButtonObjects3[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects3);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").isUsingControl("Up") ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDPlayerObjects3[k] = gdjs.OverworldCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects3.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects3[i].setAnimationName("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects3);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").isUsingControl("Down") ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDPlayerObjects3[k] = gdjs.OverworldCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects3.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects3[i].setAnimationName("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects3);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").isUsingControl("Right") ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDPlayerObjects3[k] = gdjs.OverworldCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects3.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects3[i].setAnimationName("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects3);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").isUsingControl("Left") ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDPlayerObjects3[k] = gdjs.OverworldCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects3.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects3[i].setAnimationName("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects3);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.OverworldCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").isMoving()) ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDPlayerObjects3[k] = gdjs.OverworldCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects3.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects3[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects3[i].setAnimationFrame(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects2);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isMoving() ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDPlayerObjects2[k] = gdjs.OverworldCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects2.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects2[i].playAnimation();
}
}}

}


};gdjs.OverworldCode.eventsList2 = function(runtimeScene) {

{


gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
{gdjs.OverworldCode.conditionTrue_1 = gdjs.OverworldCode.condition0IsTrue_0;
gdjs.OverworldCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15547372);
}
}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("E"), gdjs.OverworldCode.GDEObjects3);
gdjs.copyArray(runtimeScene.getObjects("E3"), gdjs.OverworldCode.GDE3Objects3);
gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.OverworldCode.GDNoButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.OverworldCode.GDYesButtonObjects3);
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects3[i].activateBehavior("TopDownMovement", true);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDEObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDEObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDE3Objects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDE3Objects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDYesButtonObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDYesButtonObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDNoButtonObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDNoButtonObjects3[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects3);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").isUsingControl("Up") ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDPlayerObjects3[k] = gdjs.OverworldCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects3.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects3[i].setAnimationName("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects3);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").isUsingControl("Down") ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDPlayerObjects3[k] = gdjs.OverworldCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects3.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects3[i].setAnimationName("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects3);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").isUsingControl("Right") ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDPlayerObjects3[k] = gdjs.OverworldCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects3.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects3[i].setAnimationName("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects3);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").isUsingControl("Left") ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDPlayerObjects3[k] = gdjs.OverworldCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects3.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects3[i].setAnimationName("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects3);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.OverworldCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").isMoving()) ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDPlayerObjects3[k] = gdjs.OverworldCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects3.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects3[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects3[i].setAnimationFrame(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects2);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isMoving() ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDPlayerObjects2[k] = gdjs.OverworldCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects2.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects2[i].playAnimation();
}
}}

}


};gdjs.OverworldCode.eventsList3 = function(runtimeScene) {

{


gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
{gdjs.OverworldCode.conditionTrue_1 = gdjs.OverworldCode.condition0IsTrue_0;
gdjs.OverworldCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15553172);
}
}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("E"), gdjs.OverworldCode.GDEObjects2);
gdjs.copyArray(runtimeScene.getObjects("E3"), gdjs.OverworldCode.GDE3Objects2);
gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.OverworldCode.GDNoButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.OverworldCode.GDYesButtonObjects2);
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects2[i].activateBehavior("TopDownMovement", true);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDEObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDEObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDE3Objects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDE3Objects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDYesButtonObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDYesButtonObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDNoButtonObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDNoButtonObjects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects2);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isUsingControl("Up") ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDPlayerObjects2[k] = gdjs.OverworldCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects2.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects2[i].setAnimationName("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects2);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isUsingControl("Down") ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDPlayerObjects2[k] = gdjs.OverworldCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects2.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects2[i].setAnimationName("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects2);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isUsingControl("Right") ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDPlayerObjects2[k] = gdjs.OverworldCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects2.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects2[i].setAnimationName("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects2);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isUsingControl("Left") ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDPlayerObjects2[k] = gdjs.OverworldCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects2.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects2[i].setAnimationName("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects2);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.OverworldCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isMoving()) ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDPlayerObjects2[k] = gdjs.OverworldCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects2.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects2[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects2[i].setAnimationFrame(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects1);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").isMoving() ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDPlayerObjects1[k] = gdjs.OverworldCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects1.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects1[i].playAnimation();
}
}}

}


};gdjs.OverworldCode.eventsList4 = function(runtimeScene) {

{


gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
gdjs.OverworldCode.condition0IsTrue_0.val = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Dialogue"));
}if (gdjs.OverworldCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.OverworldCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
gdjs.OverworldCode.condition0IsTrue_0.val = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Dialogue4"));
}if (gdjs.OverworldCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.OverworldCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
gdjs.OverworldCode.condition0IsTrue_0.val = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Dialogue2"));
}if (gdjs.OverworldCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.OverworldCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
gdjs.OverworldCode.condition0IsTrue_0.val = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Dialogue3"));
}if (gdjs.OverworldCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.OverworldCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.OverworldCode.mapOfGDgdjs_46OverworldCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.OverworldCode.GDPlayerObjects2});
gdjs.OverworldCode.mapOfGDgdjs_46OverworldCode_46GDNPCObjects2Objects = Hashtable.newFrom({"NPC": gdjs.OverworldCode.GDNPCObjects2});
gdjs.OverworldCode.eventsList5 = function(runtimeScene) {

{


gdjs.OverworldCode.condition0IsTrue_0.val = false;
gdjs.OverworldCode.condition1IsTrue_0.val = false;
{
gdjs.OverworldCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.OverworldCode.condition0IsTrue_0.val ) {
{
{gdjs.OverworldCode.conditionTrue_1 = gdjs.OverworldCode.condition1IsTrue_0;
gdjs.OverworldCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15560124);
}
}}
if (gdjs.OverworldCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("E"), gdjs.OverworldCode.GDEObjects2);
gdjs.copyArray(runtimeScene.getObjects("E3"), gdjs.OverworldCode.GDE3Objects2);
{gdjs.evtTools.camera.showLayer(runtimeScene, "Dialogue");
}{for(var i = 0, len = gdjs.OverworldCode.GDEObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDEObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDE3Objects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDE3Objects2[i].hide();
}
}}

}


};gdjs.OverworldCode.asyncCallback15565612 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Dialogue3");
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Battle");
}}
gdjs.OverworldCode.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.OverworldCode.asyncCallback15565612(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.OverworldCode.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.OverworldCode.GDYesButtonObjects2, gdjs.OverworldCode.GDYesButtonObjects3);


gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDYesButtonObjects3.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDYesButtonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDYesButtonObjects3[k] = gdjs.OverworldCode.GDYesButtonObjects3[i];
        ++k;
    }
}
gdjs.OverworldCode.GDYesButtonObjects3.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Transition"), gdjs.OverworldCode.GDTransitionObjects3);
{for(var i = 0, len = gdjs.OverworldCode.GDTransitionObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDTransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 1, "Circular", "Forward", 255, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.OverworldCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.OverworldCode.GDNoButtonObjects2);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDNoButtonObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDNoButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDNoButtonObjects2[k] = gdjs.OverworldCode.GDNoButtonObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDNoButtonObjects2.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Dialogue");
}}

}


};gdjs.OverworldCode.eventsList8 = function(runtimeScene) {

{


gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
{gdjs.OverworldCode.conditionTrue_1 = gdjs.OverworldCode.condition0IsTrue_0;
gdjs.OverworldCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15561172);
}
}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.OverworldCode.GDDialogueObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.OverworldCode.GDDialogueObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDDialogueObjects2[i].getBehavior("BitmapText_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects2[i].activateBehavior("TopDownMovement", false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Talk.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.OverworldCode.GDDialogueObjects2);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
gdjs.OverworldCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDDialogueObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDDialogueObjects2[i].getBehavior("BitmapText_AutoTyping").TypingFinished((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDDialogueObjects2[k] = gdjs.OverworldCode.GDDialogueObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDDialogueObjects2.length = k;}if ( gdjs.OverworldCode.condition0IsTrue_0.val ) {
{
{gdjs.OverworldCode.conditionTrue_1 = gdjs.OverworldCode.condition1IsTrue_0;
gdjs.OverworldCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15563412);
}
}}
if (gdjs.OverworldCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.OverworldCode.GDNoButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.OverworldCode.GDYesButtonObjects2);
{for(var i = 0, len = gdjs.OverworldCode.GDYesButtonObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDYesButtonObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDNoButtonObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDNoButtonObjects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.OverworldCode.GDYesButtonObjects2);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDYesButtonObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDYesButtonObjects2[i].isVisible() ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDYesButtonObjects2[k] = gdjs.OverworldCode.GDYesButtonObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDYesButtonObjects2.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.OverworldCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.OverworldCode.GDNoButtonObjects1.length = 0;

gdjs.OverworldCode.GDYesButtonObjects1.length = 0;


gdjs.OverworldCode.condition0IsTrue_0.val = false;
gdjs.OverworldCode.condition1IsTrue_0.val = false;
{
{gdjs.OverworldCode.conditionTrue_1 = gdjs.OverworldCode.condition0IsTrue_0;
gdjs.OverworldCode.GDNoButtonObjects1_1final.length = 0;gdjs.OverworldCode.GDYesButtonObjects1_1final.length = 0;gdjs.OverworldCode.condition0IsTrue_1.val = false;
gdjs.OverworldCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.OverworldCode.GDNoButtonObjects2);
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDNoButtonObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDNoButtonObjects2[i].IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.OverworldCode.condition0IsTrue_1.val = true;
        gdjs.OverworldCode.GDNoButtonObjects2[k] = gdjs.OverworldCode.GDNoButtonObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDNoButtonObjects2.length = k;if( gdjs.OverworldCode.condition0IsTrue_1.val ) {
    gdjs.OverworldCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.OverworldCode.GDNoButtonObjects2.length;j<jLen;++j) {
        if ( gdjs.OverworldCode.GDNoButtonObjects1_1final.indexOf(gdjs.OverworldCode.GDNoButtonObjects2[j]) === -1 )
            gdjs.OverworldCode.GDNoButtonObjects1_1final.push(gdjs.OverworldCode.GDNoButtonObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.OverworldCode.GDYesButtonObjects2);
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDYesButtonObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDYesButtonObjects2[i].IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.OverworldCode.condition1IsTrue_1.val = true;
        gdjs.OverworldCode.GDYesButtonObjects2[k] = gdjs.OverworldCode.GDYesButtonObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDYesButtonObjects2.length = k;if( gdjs.OverworldCode.condition1IsTrue_1.val ) {
    gdjs.OverworldCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.OverworldCode.GDYesButtonObjects2.length;j<jLen;++j) {
        if ( gdjs.OverworldCode.GDYesButtonObjects1_1final.indexOf(gdjs.OverworldCode.GDYesButtonObjects2[j]) === -1 )
            gdjs.OverworldCode.GDYesButtonObjects1_1final.push(gdjs.OverworldCode.GDYesButtonObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.OverworldCode.GDNoButtonObjects1_1final, gdjs.OverworldCode.GDNoButtonObjects1);
gdjs.copyArray(gdjs.OverworldCode.GDYesButtonObjects1_1final, gdjs.OverworldCode.GDYesButtonObjects1);
}
}
}if ( gdjs.OverworldCode.condition0IsTrue_0.val ) {
{
{gdjs.OverworldCode.conditionTrue_1 = gdjs.OverworldCode.condition1IsTrue_0;
gdjs.OverworldCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15568372);
}
}}
if (gdjs.OverworldCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "HoverSound.wav", false, 20, gdjs.randomFloatInRange(0.8, 0.9));
}}

}


};gdjs.OverworldCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NPC"), gdjs.OverworldCode.GDNPCObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects2);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
gdjs.OverworldCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.OverworldCode.mapOfGDgdjs_46OverworldCode_46GDPlayerObjects2Objects, gdjs.OverworldCode.mapOfGDgdjs_46OverworldCode_46GDNPCObjects2Objects, 20, false);
}if (gdjs.OverworldCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.OverworldCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
gdjs.OverworldCode.condition0IsTrue_0.val = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Dialogue");
}if (gdjs.OverworldCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.OverworldCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.OverworldCode.mapOfGDgdjs_46OverworldCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.OverworldCode.GDPlayerObjects2});
gdjs.OverworldCode.mapOfGDgdjs_46OverworldCode_46GDMaleCharacter8Objects2Objects = Hashtable.newFrom({"MaleCharacter8": gdjs.OverworldCode.GDMaleCharacter8Objects2});
gdjs.OverworldCode.eventsList10 = function(runtimeScene) {

{


gdjs.OverworldCode.condition0IsTrue_0.val = false;
gdjs.OverworldCode.condition1IsTrue_0.val = false;
{
gdjs.OverworldCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.OverworldCode.condition0IsTrue_0.val ) {
{
{gdjs.OverworldCode.conditionTrue_1 = gdjs.OverworldCode.condition1IsTrue_0;
gdjs.OverworldCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15570092);
}
}}
if (gdjs.OverworldCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("E"), gdjs.OverworldCode.GDEObjects2);
gdjs.copyArray(runtimeScene.getObjects("E3"), gdjs.OverworldCode.GDE3Objects2);
{gdjs.evtTools.camera.showLayer(runtimeScene, "Dialogue4");
}{for(var i = 0, len = gdjs.OverworldCode.GDEObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDEObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDE3Objects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDE3Objects2[i].hide();
}
}}

}


};gdjs.OverworldCode.asyncCallback15548540 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Dialogue4");
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Quest");
}}
gdjs.OverworldCode.eventsList11 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.OverworldCode.asyncCallback15548540(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.OverworldCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.OverworldCode.GDYesButtonObjects2, gdjs.OverworldCode.GDYesButtonObjects3);


gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDYesButtonObjects3.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDYesButtonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDYesButtonObjects3[k] = gdjs.OverworldCode.GDYesButtonObjects3[i];
        ++k;
    }
}
gdjs.OverworldCode.GDYesButtonObjects3.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Transition"), gdjs.OverworldCode.GDTransitionObjects3);
{for(var i = 0, len = gdjs.OverworldCode.GDTransitionObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDTransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 1, "Circular", "Forward", 255, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.OverworldCode.eventsList11(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.OverworldCode.GDNoButtonObjects2);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDNoButtonObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDNoButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDNoButtonObjects2[k] = gdjs.OverworldCode.GDNoButtonObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDNoButtonObjects2.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Dialogue4");
}}

}


};gdjs.OverworldCode.eventsList13 = function(runtimeScene) {

{


gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
{gdjs.OverworldCode.conditionTrue_1 = gdjs.OverworldCode.condition0IsTrue_0;
gdjs.OverworldCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15570788);
}
}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Dialogue4"), gdjs.OverworldCode.GDDialogue4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.OverworldCode.GDDialogue4Objects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDDialogue4Objects2[i].getBehavior("BitmapText_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects2[i].activateBehavior("TopDownMovement", false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Talk.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Dialogue4"), gdjs.OverworldCode.GDDialogue4Objects2);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
gdjs.OverworldCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDDialogue4Objects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDDialogue4Objects2[i].getBehavior("BitmapText_AutoTyping").TypingFinished((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDDialogue4Objects2[k] = gdjs.OverworldCode.GDDialogue4Objects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDDialogue4Objects2.length = k;}if ( gdjs.OverworldCode.condition0IsTrue_0.val ) {
{
{gdjs.OverworldCode.conditionTrue_1 = gdjs.OverworldCode.condition1IsTrue_0;
gdjs.OverworldCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15573548);
}
}}
if (gdjs.OverworldCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.OverworldCode.GDNoButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.OverworldCode.GDYesButtonObjects2);
{for(var i = 0, len = gdjs.OverworldCode.GDYesButtonObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDYesButtonObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDNoButtonObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDNoButtonObjects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.OverworldCode.GDYesButtonObjects2);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDYesButtonObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDYesButtonObjects2[i].isVisible() ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDYesButtonObjects2[k] = gdjs.OverworldCode.GDYesButtonObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDYesButtonObjects2.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.OverworldCode.eventsList12(runtimeScene);} //End of subevents
}

}


{

gdjs.OverworldCode.GDNoButtonObjects1.length = 0;

gdjs.OverworldCode.GDYesButtonObjects1.length = 0;


gdjs.OverworldCode.condition0IsTrue_0.val = false;
gdjs.OverworldCode.condition1IsTrue_0.val = false;
{
{gdjs.OverworldCode.conditionTrue_1 = gdjs.OverworldCode.condition0IsTrue_0;
gdjs.OverworldCode.GDNoButtonObjects1_1final.length = 0;gdjs.OverworldCode.GDYesButtonObjects1_1final.length = 0;gdjs.OverworldCode.condition0IsTrue_1.val = false;
gdjs.OverworldCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.OverworldCode.GDNoButtonObjects2);
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDNoButtonObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDNoButtonObjects2[i].IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.OverworldCode.condition0IsTrue_1.val = true;
        gdjs.OverworldCode.GDNoButtonObjects2[k] = gdjs.OverworldCode.GDNoButtonObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDNoButtonObjects2.length = k;if( gdjs.OverworldCode.condition0IsTrue_1.val ) {
    gdjs.OverworldCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.OverworldCode.GDNoButtonObjects2.length;j<jLen;++j) {
        if ( gdjs.OverworldCode.GDNoButtonObjects1_1final.indexOf(gdjs.OverworldCode.GDNoButtonObjects2[j]) === -1 )
            gdjs.OverworldCode.GDNoButtonObjects1_1final.push(gdjs.OverworldCode.GDNoButtonObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.OverworldCode.GDYesButtonObjects2);
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDYesButtonObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDYesButtonObjects2[i].IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.OverworldCode.condition1IsTrue_1.val = true;
        gdjs.OverworldCode.GDYesButtonObjects2[k] = gdjs.OverworldCode.GDYesButtonObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDYesButtonObjects2.length = k;if( gdjs.OverworldCode.condition1IsTrue_1.val ) {
    gdjs.OverworldCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.OverworldCode.GDYesButtonObjects2.length;j<jLen;++j) {
        if ( gdjs.OverworldCode.GDYesButtonObjects1_1final.indexOf(gdjs.OverworldCode.GDYesButtonObjects2[j]) === -1 )
            gdjs.OverworldCode.GDYesButtonObjects1_1final.push(gdjs.OverworldCode.GDYesButtonObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.OverworldCode.GDNoButtonObjects1_1final, gdjs.OverworldCode.GDNoButtonObjects1);
gdjs.copyArray(gdjs.OverworldCode.GDYesButtonObjects1_1final, gdjs.OverworldCode.GDYesButtonObjects1);
}
}
}if ( gdjs.OverworldCode.condition0IsTrue_0.val ) {
{
{gdjs.OverworldCode.conditionTrue_1 = gdjs.OverworldCode.condition1IsTrue_0;
gdjs.OverworldCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15523996);
}
}}
if (gdjs.OverworldCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "HoverSound.wav", false, 20, gdjs.randomFloatInRange(0.8, 0.9));
}}

}


};gdjs.OverworldCode.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("MaleCharacter8"), gdjs.OverworldCode.GDMaleCharacter8Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects2);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
gdjs.OverworldCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.OverworldCode.mapOfGDgdjs_46OverworldCode_46GDPlayerObjects2Objects, gdjs.OverworldCode.mapOfGDgdjs_46OverworldCode_46GDMaleCharacter8Objects2Objects, 20, false);
}if (gdjs.OverworldCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.OverworldCode.eventsList10(runtimeScene);} //End of subevents
}

}


{


gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
gdjs.OverworldCode.condition0IsTrue_0.val = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Dialogue4");
}if (gdjs.OverworldCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.OverworldCode.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.OverworldCode.mapOfGDgdjs_46OverworldCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.OverworldCode.GDPlayerObjects2});
gdjs.OverworldCode.mapOfGDgdjs_46OverworldCode_46GDNPC2Objects2Objects = Hashtable.newFrom({"NPC2": gdjs.OverworldCode.GDNPC2Objects2});
gdjs.OverworldCode.eventsList15 = function(runtimeScene) {

{


gdjs.OverworldCode.condition0IsTrue_0.val = false;
gdjs.OverworldCode.condition1IsTrue_0.val = false;
{
gdjs.OverworldCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.OverworldCode.condition0IsTrue_0.val ) {
{
{gdjs.OverworldCode.conditionTrue_1 = gdjs.OverworldCode.condition1IsTrue_0;
gdjs.OverworldCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15522372);
}
}}
if (gdjs.OverworldCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("E"), gdjs.OverworldCode.GDEObjects2);
gdjs.copyArray(runtimeScene.getObjects("E3"), gdjs.OverworldCode.GDE3Objects2);
{gdjs.evtTools.camera.showLayer(runtimeScene, "Dialogue2");
}{for(var i = 0, len = gdjs.OverworldCode.GDEObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDEObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDE3Objects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDE3Objects2[i].hide();
}
}}

}


};gdjs.OverworldCode.asyncCallback15530428 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Dialogue2");
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "forest");
}}
gdjs.OverworldCode.eventsList16 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.OverworldCode.asyncCallback15530428(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.OverworldCode.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.OverworldCode.GDYesButtonObjects2, gdjs.OverworldCode.GDYesButtonObjects3);


gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDYesButtonObjects3.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDYesButtonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDYesButtonObjects3[k] = gdjs.OverworldCode.GDYesButtonObjects3[i];
        ++k;
    }
}
gdjs.OverworldCode.GDYesButtonObjects3.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Transition"), gdjs.OverworldCode.GDTransitionObjects3);
{for(var i = 0, len = gdjs.OverworldCode.GDTransitionObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDTransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 1, "Circular", "Forward", 255, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.OverworldCode.eventsList16(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.OverworldCode.GDNoButtonObjects2);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDNoButtonObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDNoButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDNoButtonObjects2[k] = gdjs.OverworldCode.GDNoButtonObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDNoButtonObjects2.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Dialogue2");
}}

}


};gdjs.OverworldCode.eventsList18 = function(runtimeScene) {

{


gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
{gdjs.OverworldCode.conditionTrue_1 = gdjs.OverworldCode.condition0IsTrue_0;
gdjs.OverworldCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15568852);
}
}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Dialogue2"), gdjs.OverworldCode.GDDialogue2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.OverworldCode.GDDialogue2Objects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDDialogue2Objects2[i].getBehavior("BitmapText_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects2[i].activateBehavior("TopDownMovement", false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Talk.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Dialogue2"), gdjs.OverworldCode.GDDialogue2Objects2);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
gdjs.OverworldCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDDialogue2Objects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDDialogue2Objects2[i].getBehavior("BitmapText_AutoTyping").TypingFinished((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDDialogue2Objects2[k] = gdjs.OverworldCode.GDDialogue2Objects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDDialogue2Objects2.length = k;}if ( gdjs.OverworldCode.condition0IsTrue_0.val ) {
{
{gdjs.OverworldCode.conditionTrue_1 = gdjs.OverworldCode.condition1IsTrue_0;
gdjs.OverworldCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15562956);
}
}}
if (gdjs.OverworldCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.OverworldCode.GDNoButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.OverworldCode.GDYesButtonObjects2);
{for(var i = 0, len = gdjs.OverworldCode.GDYesButtonObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDYesButtonObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDNoButtonObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDNoButtonObjects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.OverworldCode.GDYesButtonObjects2);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDYesButtonObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDYesButtonObjects2[i].isVisible() ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDYesButtonObjects2[k] = gdjs.OverworldCode.GDYesButtonObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDYesButtonObjects2.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.OverworldCode.eventsList17(runtimeScene);} //End of subevents
}

}


{

gdjs.OverworldCode.GDNoButtonObjects1.length = 0;

gdjs.OverworldCode.GDYesButtonObjects1.length = 0;


gdjs.OverworldCode.condition0IsTrue_0.val = false;
gdjs.OverworldCode.condition1IsTrue_0.val = false;
{
{gdjs.OverworldCode.conditionTrue_1 = gdjs.OverworldCode.condition0IsTrue_0;
gdjs.OverworldCode.GDNoButtonObjects1_1final.length = 0;gdjs.OverworldCode.GDYesButtonObjects1_1final.length = 0;gdjs.OverworldCode.condition0IsTrue_1.val = false;
gdjs.OverworldCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.OverworldCode.GDNoButtonObjects2);
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDNoButtonObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDNoButtonObjects2[i].IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.OverworldCode.condition0IsTrue_1.val = true;
        gdjs.OverworldCode.GDNoButtonObjects2[k] = gdjs.OverworldCode.GDNoButtonObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDNoButtonObjects2.length = k;if( gdjs.OverworldCode.condition0IsTrue_1.val ) {
    gdjs.OverworldCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.OverworldCode.GDNoButtonObjects2.length;j<jLen;++j) {
        if ( gdjs.OverworldCode.GDNoButtonObjects1_1final.indexOf(gdjs.OverworldCode.GDNoButtonObjects2[j]) === -1 )
            gdjs.OverworldCode.GDNoButtonObjects1_1final.push(gdjs.OverworldCode.GDNoButtonObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.OverworldCode.GDYesButtonObjects2);
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDYesButtonObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDYesButtonObjects2[i].IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.OverworldCode.condition1IsTrue_1.val = true;
        gdjs.OverworldCode.GDYesButtonObjects2[k] = gdjs.OverworldCode.GDYesButtonObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDYesButtonObjects2.length = k;if( gdjs.OverworldCode.condition1IsTrue_1.val ) {
    gdjs.OverworldCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.OverworldCode.GDYesButtonObjects2.length;j<jLen;++j) {
        if ( gdjs.OverworldCode.GDYesButtonObjects1_1final.indexOf(gdjs.OverworldCode.GDYesButtonObjects2[j]) === -1 )
            gdjs.OverworldCode.GDYesButtonObjects1_1final.push(gdjs.OverworldCode.GDYesButtonObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.OverworldCode.GDNoButtonObjects1_1final, gdjs.OverworldCode.GDNoButtonObjects1);
gdjs.copyArray(gdjs.OverworldCode.GDYesButtonObjects1_1final, gdjs.OverworldCode.GDYesButtonObjects1);
}
}
}if ( gdjs.OverworldCode.condition0IsTrue_0.val ) {
{
{gdjs.OverworldCode.conditionTrue_1 = gdjs.OverworldCode.condition1IsTrue_0;
gdjs.OverworldCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15524908);
}
}}
if (gdjs.OverworldCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "HoverSound.wav", false, 20, gdjs.randomFloatInRange(0.8, 0.9));
}}

}


};gdjs.OverworldCode.eventsList19 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NPC2"), gdjs.OverworldCode.GDNPC2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects2);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
gdjs.OverworldCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.OverworldCode.mapOfGDgdjs_46OverworldCode_46GDPlayerObjects2Objects, gdjs.OverworldCode.mapOfGDgdjs_46OverworldCode_46GDNPC2Objects2Objects, 20, false);
}if (gdjs.OverworldCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.OverworldCode.eventsList15(runtimeScene);} //End of subevents
}

}


{


gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
gdjs.OverworldCode.condition0IsTrue_0.val = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Dialogue2");
}if (gdjs.OverworldCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.OverworldCode.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.OverworldCode.mapOfGDgdjs_46OverworldCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.OverworldCode.GDPlayerObjects2});
gdjs.OverworldCode.mapOfGDgdjs_46OverworldCode_46GDFishermanObjects2Objects = Hashtable.newFrom({"Fisherman": gdjs.OverworldCode.GDFishermanObjects2});
gdjs.OverworldCode.eventsList20 = function(runtimeScene) {

{


gdjs.OverworldCode.condition0IsTrue_0.val = false;
gdjs.OverworldCode.condition1IsTrue_0.val = false;
{
gdjs.OverworldCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.OverworldCode.condition0IsTrue_0.val ) {
{
{gdjs.OverworldCode.conditionTrue_1 = gdjs.OverworldCode.condition1IsTrue_0;
gdjs.OverworldCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15575652);
}
}}
if (gdjs.OverworldCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("E"), gdjs.OverworldCode.GDEObjects2);
gdjs.copyArray(runtimeScene.getObjects("E3"), gdjs.OverworldCode.GDE3Objects2);
{gdjs.evtTools.camera.showLayer(runtimeScene, "Dialogue3");
}{for(var i = 0, len = gdjs.OverworldCode.GDEObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDEObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDE3Objects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDE3Objects2[i].hide();
}
}}

}


};gdjs.OverworldCode.asyncCallback15579652 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Dialogue3");
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Fish");
}}
gdjs.OverworldCode.eventsList21 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.OverworldCode.asyncCallback15579652(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.OverworldCode.eventsList22 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.OverworldCode.GDYesButtonObjects2, gdjs.OverworldCode.GDYesButtonObjects3);


gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDYesButtonObjects3.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDYesButtonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDYesButtonObjects3[k] = gdjs.OverworldCode.GDYesButtonObjects3[i];
        ++k;
    }
}
gdjs.OverworldCode.GDYesButtonObjects3.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Transition"), gdjs.OverworldCode.GDTransitionObjects3);
{for(var i = 0, len = gdjs.OverworldCode.GDTransitionObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDTransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 1, "Circular", "Forward", 255, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.OverworldCode.eventsList21(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.OverworldCode.GDNoButtonObjects2);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDNoButtonObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDNoButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDNoButtonObjects2[k] = gdjs.OverworldCode.GDNoButtonObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDNoButtonObjects2.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Dialogue3");
}}

}


};gdjs.OverworldCode.eventsList23 = function(runtimeScene) {

{


gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
{gdjs.OverworldCode.conditionTrue_1 = gdjs.OverworldCode.condition0IsTrue_0;
gdjs.OverworldCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15576772);
}
}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Dialogue3"), gdjs.OverworldCode.GDDialogue3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.OverworldCode.GDDialogue3Objects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDDialogue3Objects2[i].getBehavior("BitmapText_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects2[i].activateBehavior("TopDownMovement", false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Talk.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Dialogue3"), gdjs.OverworldCode.GDDialogue3Objects2);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
gdjs.OverworldCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDDialogue3Objects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDDialogue3Objects2[i].getBehavior("BitmapText_AutoTyping").TypingFinished((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDDialogue3Objects2[k] = gdjs.OverworldCode.GDDialogue3Objects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDDialogue3Objects2.length = k;}if ( gdjs.OverworldCode.condition0IsTrue_0.val ) {
{
{gdjs.OverworldCode.conditionTrue_1 = gdjs.OverworldCode.condition1IsTrue_0;
gdjs.OverworldCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15578068);
}
}}
if (gdjs.OverworldCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.OverworldCode.GDNoButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.OverworldCode.GDYesButtonObjects2);
{for(var i = 0, len = gdjs.OverworldCode.GDYesButtonObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDYesButtonObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDNoButtonObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDNoButtonObjects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.OverworldCode.GDYesButtonObjects2);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDYesButtonObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDYesButtonObjects2[i].isVisible() ) {
        gdjs.OverworldCode.condition0IsTrue_0.val = true;
        gdjs.OverworldCode.GDYesButtonObjects2[k] = gdjs.OverworldCode.GDYesButtonObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDYesButtonObjects2.length = k;}if (gdjs.OverworldCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.OverworldCode.eventsList22(runtimeScene);} //End of subevents
}

}


{

gdjs.OverworldCode.GDNoButtonObjects1.length = 0;

gdjs.OverworldCode.GDYesButtonObjects1.length = 0;


gdjs.OverworldCode.condition0IsTrue_0.val = false;
gdjs.OverworldCode.condition1IsTrue_0.val = false;
{
{gdjs.OverworldCode.conditionTrue_1 = gdjs.OverworldCode.condition0IsTrue_0;
gdjs.OverworldCode.GDNoButtonObjects1_1final.length = 0;gdjs.OverworldCode.GDYesButtonObjects1_1final.length = 0;gdjs.OverworldCode.condition0IsTrue_1.val = false;
gdjs.OverworldCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.OverworldCode.GDNoButtonObjects2);
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDNoButtonObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDNoButtonObjects2[i].IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.OverworldCode.condition0IsTrue_1.val = true;
        gdjs.OverworldCode.GDNoButtonObjects2[k] = gdjs.OverworldCode.GDNoButtonObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDNoButtonObjects2.length = k;if( gdjs.OverworldCode.condition0IsTrue_1.val ) {
    gdjs.OverworldCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.OverworldCode.GDNoButtonObjects2.length;j<jLen;++j) {
        if ( gdjs.OverworldCode.GDNoButtonObjects1_1final.indexOf(gdjs.OverworldCode.GDNoButtonObjects2[j]) === -1 )
            gdjs.OverworldCode.GDNoButtonObjects1_1final.push(gdjs.OverworldCode.GDNoButtonObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.OverworldCode.GDYesButtonObjects2);
for(var i = 0, k = 0, l = gdjs.OverworldCode.GDYesButtonObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDYesButtonObjects2[i].IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.OverworldCode.condition1IsTrue_1.val = true;
        gdjs.OverworldCode.GDYesButtonObjects2[k] = gdjs.OverworldCode.GDYesButtonObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDYesButtonObjects2.length = k;if( gdjs.OverworldCode.condition1IsTrue_1.val ) {
    gdjs.OverworldCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.OverworldCode.GDYesButtonObjects2.length;j<jLen;++j) {
        if ( gdjs.OverworldCode.GDYesButtonObjects1_1final.indexOf(gdjs.OverworldCode.GDYesButtonObjects2[j]) === -1 )
            gdjs.OverworldCode.GDYesButtonObjects1_1final.push(gdjs.OverworldCode.GDYesButtonObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.OverworldCode.GDNoButtonObjects1_1final, gdjs.OverworldCode.GDNoButtonObjects1);
gdjs.copyArray(gdjs.OverworldCode.GDYesButtonObjects1_1final, gdjs.OverworldCode.GDYesButtonObjects1);
}
}
}if ( gdjs.OverworldCode.condition0IsTrue_0.val ) {
{
{gdjs.OverworldCode.conditionTrue_1 = gdjs.OverworldCode.condition1IsTrue_0;
gdjs.OverworldCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15581604);
}
}}
if (gdjs.OverworldCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "HoverSound.wav", false, 20, gdjs.randomFloatInRange(0.8, 0.9));
}}

}


};gdjs.OverworldCode.eventsList24 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Fisherman"), gdjs.OverworldCode.GDFishermanObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects2);

gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
gdjs.OverworldCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.OverworldCode.mapOfGDgdjs_46OverworldCode_46GDPlayerObjects2Objects, gdjs.OverworldCode.mapOfGDgdjs_46OverworldCode_46GDFishermanObjects2Objects, 20, false);
}if (gdjs.OverworldCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.OverworldCode.eventsList20(runtimeScene);} //End of subevents
}

}


{


gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
gdjs.OverworldCode.condition0IsTrue_0.val = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Dialogue3");
}if (gdjs.OverworldCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.OverworldCode.eventsList23(runtimeScene);} //End of subevents
}

}


};gdjs.OverworldCode.eventsList25 = function(runtimeScene) {

};gdjs.OverworldCode.eventsList26 = function(runtimeScene) {

{


gdjs.OverworldCode.condition0IsTrue_0.val = false;
{
gdjs.OverworldCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.OverworldCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Bush1"), gdjs.OverworldCode.GDBush1Objects1);
gdjs.copyArray(runtimeScene.getObjects("CollisionDetect"), gdjs.OverworldCode.GDCollisionDetectObjects1);
gdjs.copyArray(runtimeScene.getObjects("E"), gdjs.OverworldCode.GDEObjects1);
gdjs.copyArray(runtimeScene.getObjects("E3"), gdjs.OverworldCode.GDE3Objects1);
gdjs.copyArray(runtimeScene.getObjects("House1"), gdjs.OverworldCode.GDHouse1Objects1);
gdjs.copyArray(runtimeScene.getObjects("House2"), gdjs.OverworldCode.GDHouse2Objects1);
gdjs.copyArray(runtimeScene.getObjects("NPC"), gdjs.OverworldCode.GDNPCObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tree1"), gdjs.OverworldCode.GDTree1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tree2"), gdjs.OverworldCode.GDTree2Objects1);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 6, "", 0);
}{for(var i = 0, len = gdjs.OverworldCode.GDTree1Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDTree1Objects1[i].setZOrder((gdjs.OverworldCode.GDTree1Objects1[i].getPointY("")));
}
for(var i = 0, len = gdjs.OverworldCode.GDBush1Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDBush1Objects1[i].setZOrder((gdjs.OverworldCode.GDBush1Objects1[i].getPointY("")));
}
for(var i = 0, len = gdjs.OverworldCode.GDTree2Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDTree2Objects1[i].setZOrder((gdjs.OverworldCode.GDTree2Objects1[i].getPointY("")));
}
for(var i = 0, len = gdjs.OverworldCode.GDHouse1Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDHouse1Objects1[i].setZOrder((gdjs.OverworldCode.GDHouse1Objects1[i].getPointY("")));
}
for(var i = 0, len = gdjs.OverworldCode.GDHouse2Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDHouse2Objects1[i].setZOrder((gdjs.OverworldCode.GDHouse2Objects1[i].getPointY("")));
}
for(var i = 0, len = gdjs.OverworldCode.GDNPCObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDNPCObjects1[i].setZOrder((gdjs.OverworldCode.GDNPCObjects1[i].getPointY("")));
}
}{for(var i = 0, len = gdjs.OverworldCode.GDCollisionDetectObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDCollisionDetectObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDEObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDEObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 0, 2, 10, 1, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.OverworldCode.GDE3Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDE3Objects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 0, 2, 10, 1, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1.5, "Transition", 0);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("CollisionDetect"), gdjs.OverworldCode.GDCollisionDetectObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects1[i].setZOrder((gdjs.OverworldCode.GDPlayerObjects1[i].getPointY("")));
}
}{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects1[i].separateFromObjectsList(gdjs.OverworldCode.mapOfGDgdjs_46OverworldCode_46GDCollisionDetectObjects1Objects, false);
}
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.OverworldCode.GDPlayerObjects1.length !== 0 ? gdjs.OverworldCode.GDPlayerObjects1[0] : null), true, "", 0);
}}

}


{


gdjs.OverworldCode.eventsList4(runtimeScene);
}


{


gdjs.OverworldCode.eventsList9(runtimeScene);
}


{


gdjs.OverworldCode.eventsList14(runtimeScene);
}


{


gdjs.OverworldCode.eventsList19(runtimeScene);
}


{


gdjs.OverworldCode.eventsList24(runtimeScene);
}


{


{
}

}


{


gdjs.OverworldCode.eventsList25(runtimeScene);
}


{


{
gdjs.copyArray(runtimeScene.getObjects("Tasks"), gdjs.OverworldCode.GDTasksObjects1);
{for(var i = 0, len = gdjs.OverworldCode.GDTasksObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDTasksObjects1[i].setString("Tasks Completed: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().get("tasks")) + "/2");
}
}}

}


};

gdjs.OverworldCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.OverworldCode.GDTransitionObjects1.length = 0;
gdjs.OverworldCode.GDTransitionObjects2.length = 0;
gdjs.OverworldCode.GDTransitionObjects3.length = 0;
gdjs.OverworldCode.GDTransitionObjects4.length = 0;
gdjs.OverworldCode.GDPlayerObjects1.length = 0;
gdjs.OverworldCode.GDPlayerObjects2.length = 0;
gdjs.OverworldCode.GDPlayerObjects3.length = 0;
gdjs.OverworldCode.GDPlayerObjects4.length = 0;
gdjs.OverworldCode.GDDock1Objects1.length = 0;
gdjs.OverworldCode.GDDock1Objects2.length = 0;
gdjs.OverworldCode.GDDock1Objects3.length = 0;
gdjs.OverworldCode.GDDock1Objects4.length = 0;
gdjs.OverworldCode.GDFishermanObjects1.length = 0;
gdjs.OverworldCode.GDFishermanObjects2.length = 0;
gdjs.OverworldCode.GDFishermanObjects3.length = 0;
gdjs.OverworldCode.GDFishermanObjects4.length = 0;
gdjs.OverworldCode.GDWater1Objects1.length = 0;
gdjs.OverworldCode.GDWater1Objects2.length = 0;
gdjs.OverworldCode.GDWater1Objects3.length = 0;
gdjs.OverworldCode.GDWater1Objects4.length = 0;
gdjs.OverworldCode.GDTextBorderObjects1.length = 0;
gdjs.OverworldCode.GDTextBorderObjects2.length = 0;
gdjs.OverworldCode.GDTextBorderObjects3.length = 0;
gdjs.OverworldCode.GDTextBorderObjects4.length = 0;
gdjs.OverworldCode.GDCollisionDetectObjects1.length = 0;
gdjs.OverworldCode.GDCollisionDetectObjects2.length = 0;
gdjs.OverworldCode.GDCollisionDetectObjects3.length = 0;
gdjs.OverworldCode.GDCollisionDetectObjects4.length = 0;
gdjs.OverworldCode.GDEObjects1.length = 0;
gdjs.OverworldCode.GDEObjects2.length = 0;
gdjs.OverworldCode.GDEObjects3.length = 0;
gdjs.OverworldCode.GDEObjects4.length = 0;
gdjs.OverworldCode.GDAObjects1.length = 0;
gdjs.OverworldCode.GDAObjects2.length = 0;
gdjs.OverworldCode.GDAObjects3.length = 0;
gdjs.OverworldCode.GDAObjects4.length = 0;
gdjs.OverworldCode.GDA2Objects1.length = 0;
gdjs.OverworldCode.GDA2Objects2.length = 0;
gdjs.OverworldCode.GDA2Objects3.length = 0;
gdjs.OverworldCode.GDA2Objects4.length = 0;
gdjs.OverworldCode.GDDialogueObjects1.length = 0;
gdjs.OverworldCode.GDDialogueObjects2.length = 0;
gdjs.OverworldCode.GDDialogueObjects3.length = 0;
gdjs.OverworldCode.GDDialogueObjects4.length = 0;
gdjs.OverworldCode.GDDialogue4Objects1.length = 0;
gdjs.OverworldCode.GDDialogue4Objects2.length = 0;
gdjs.OverworldCode.GDDialogue4Objects3.length = 0;
gdjs.OverworldCode.GDDialogue4Objects4.length = 0;
gdjs.OverworldCode.GDYesButtonObjects1.length = 0;
gdjs.OverworldCode.GDYesButtonObjects2.length = 0;
gdjs.OverworldCode.GDYesButtonObjects3.length = 0;
gdjs.OverworldCode.GDYesButtonObjects4.length = 0;
gdjs.OverworldCode.GDNoButtonObjects1.length = 0;
gdjs.OverworldCode.GDNoButtonObjects2.length = 0;
gdjs.OverworldCode.GDNoButtonObjects3.length = 0;
gdjs.OverworldCode.GDNoButtonObjects4.length = 0;
gdjs.OverworldCode.GDCornerWaterObjects1.length = 0;
gdjs.OverworldCode.GDCornerWaterObjects2.length = 0;
gdjs.OverworldCode.GDCornerWaterObjects3.length = 0;
gdjs.OverworldCode.GDCornerWaterObjects4.length = 0;
gdjs.OverworldCode.GDWaterEdgeRightObjects1.length = 0;
gdjs.OverworldCode.GDWaterEdgeRightObjects2.length = 0;
gdjs.OverworldCode.GDWaterEdgeRightObjects3.length = 0;
gdjs.OverworldCode.GDWaterEdgeRightObjects4.length = 0;
gdjs.OverworldCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.OverworldCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.OverworldCode.GDNewTiledSpriteObjects3.length = 0;
gdjs.OverworldCode.GDNewTiledSpriteObjects4.length = 0;
gdjs.OverworldCode.GDGrassObjects1.length = 0;
gdjs.OverworldCode.GDGrassObjects2.length = 0;
gdjs.OverworldCode.GDGrassObjects3.length = 0;
gdjs.OverworldCode.GDGrassObjects4.length = 0;
gdjs.OverworldCode.GDTree2Objects1.length = 0;
gdjs.OverworldCode.GDTree2Objects2.length = 0;
gdjs.OverworldCode.GDTree2Objects3.length = 0;
gdjs.OverworldCode.GDTree2Objects4.length = 0;
gdjs.OverworldCode.GDNPC2Objects1.length = 0;
gdjs.OverworldCode.GDNPC2Objects2.length = 0;
gdjs.OverworldCode.GDNPC2Objects3.length = 0;
gdjs.OverworldCode.GDNPC2Objects4.length = 0;
gdjs.OverworldCode.GDBush1Objects1.length = 0;
gdjs.OverworldCode.GDBush1Objects2.length = 0;
gdjs.OverworldCode.GDBush1Objects3.length = 0;
gdjs.OverworldCode.GDBush1Objects4.length = 0;
gdjs.OverworldCode.GDLakeTroutObjects1.length = 0;
gdjs.OverworldCode.GDLakeTroutObjects2.length = 0;
gdjs.OverworldCode.GDLakeTroutObjects3.length = 0;
gdjs.OverworldCode.GDLakeTroutObjects4.length = 0;
gdjs.OverworldCode.GDPlayerObjects1.length = 0;
gdjs.OverworldCode.GDPlayerObjects2.length = 0;
gdjs.OverworldCode.GDPlayerObjects3.length = 0;
gdjs.OverworldCode.GDPlayerObjects4.length = 0;
gdjs.OverworldCode.GDNPCObjects1.length = 0;
gdjs.OverworldCode.GDNPCObjects2.length = 0;
gdjs.OverworldCode.GDNPCObjects3.length = 0;
gdjs.OverworldCode.GDNPCObjects4.length = 0;
gdjs.OverworldCode.GDNPC2Objects1.length = 0;
gdjs.OverworldCode.GDNPC2Objects2.length = 0;
gdjs.OverworldCode.GDNPC2Objects3.length = 0;
gdjs.OverworldCode.GDNPC2Objects4.length = 0;
gdjs.OverworldCode.GDDock1Objects1.length = 0;
gdjs.OverworldCode.GDDock1Objects2.length = 0;
gdjs.OverworldCode.GDDock1Objects3.length = 0;
gdjs.OverworldCode.GDDock1Objects4.length = 0;
gdjs.OverworldCode.GDTree1Objects1.length = 0;
gdjs.OverworldCode.GDTree1Objects2.length = 0;
gdjs.OverworldCode.GDTree1Objects3.length = 0;
gdjs.OverworldCode.GDTree1Objects4.length = 0;
gdjs.OverworldCode.GDTree2Objects1.length = 0;
gdjs.OverworldCode.GDTree2Objects2.length = 0;
gdjs.OverworldCode.GDTree2Objects3.length = 0;
gdjs.OverworldCode.GDTree2Objects4.length = 0;
gdjs.OverworldCode.GDBush1Objects1.length = 0;
gdjs.OverworldCode.GDBush1Objects2.length = 0;
gdjs.OverworldCode.GDBush1Objects3.length = 0;
gdjs.OverworldCode.GDBush1Objects4.length = 0;
gdjs.OverworldCode.GDHouse1Objects1.length = 0;
gdjs.OverworldCode.GDHouse1Objects2.length = 0;
gdjs.OverworldCode.GDHouse1Objects3.length = 0;
gdjs.OverworldCode.GDHouse1Objects4.length = 0;
gdjs.OverworldCode.GDHouse2Objects1.length = 0;
gdjs.OverworldCode.GDHouse2Objects2.length = 0;
gdjs.OverworldCode.GDHouse2Objects3.length = 0;
gdjs.OverworldCode.GDHouse2Objects4.length = 0;
gdjs.OverworldCode.GDCornerWaterObjects1.length = 0;
gdjs.OverworldCode.GDCornerWaterObjects2.length = 0;
gdjs.OverworldCode.GDCornerWaterObjects3.length = 0;
gdjs.OverworldCode.GDCornerWaterObjects4.length = 0;
gdjs.OverworldCode.GDWaterCorner2Objects1.length = 0;
gdjs.OverworldCode.GDWaterCorner2Objects2.length = 0;
gdjs.OverworldCode.GDWaterCorner2Objects3.length = 0;
gdjs.OverworldCode.GDWaterCorner2Objects4.length = 0;
gdjs.OverworldCode.GDGrassObjects1.length = 0;
gdjs.OverworldCode.GDGrassObjects2.length = 0;
gdjs.OverworldCode.GDGrassObjects3.length = 0;
gdjs.OverworldCode.GDGrassObjects4.length = 0;
gdjs.OverworldCode.GDWaterEdgeRightObjects1.length = 0;
gdjs.OverworldCode.GDWaterEdgeRightObjects2.length = 0;
gdjs.OverworldCode.GDWaterEdgeRightObjects3.length = 0;
gdjs.OverworldCode.GDWaterEdgeRightObjects4.length = 0;
gdjs.OverworldCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.OverworldCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.OverworldCode.GDNewTiledSpriteObjects3.length = 0;
gdjs.OverworldCode.GDNewTiledSpriteObjects4.length = 0;
gdjs.OverworldCode.GDWater1Objects1.length = 0;
gdjs.OverworldCode.GDWater1Objects2.length = 0;
gdjs.OverworldCode.GDWater1Objects3.length = 0;
gdjs.OverworldCode.GDWater1Objects4.length = 0;
gdjs.OverworldCode.GDRoad1Objects1.length = 0;
gdjs.OverworldCode.GDRoad1Objects2.length = 0;
gdjs.OverworldCode.GDRoad1Objects3.length = 0;
gdjs.OverworldCode.GDRoad1Objects4.length = 0;
gdjs.OverworldCode.GDRoadEdge1Objects1.length = 0;
gdjs.OverworldCode.GDRoadEdge1Objects2.length = 0;
gdjs.OverworldCode.GDRoadEdge1Objects3.length = 0;
gdjs.OverworldCode.GDRoadEdge1Objects4.length = 0;
gdjs.OverworldCode.GDCollisionDetectObjects1.length = 0;
gdjs.OverworldCode.GDCollisionDetectObjects2.length = 0;
gdjs.OverworldCode.GDCollisionDetectObjects3.length = 0;
gdjs.OverworldCode.GDCollisionDetectObjects4.length = 0;
gdjs.OverworldCode.GDDialogueObjects1.length = 0;
gdjs.OverworldCode.GDDialogueObjects2.length = 0;
gdjs.OverworldCode.GDDialogueObjects3.length = 0;
gdjs.OverworldCode.GDDialogueObjects4.length = 0;
gdjs.OverworldCode.GDDialogue2Objects1.length = 0;
gdjs.OverworldCode.GDDialogue2Objects2.length = 0;
gdjs.OverworldCode.GDDialogue2Objects3.length = 0;
gdjs.OverworldCode.GDDialogue2Objects4.length = 0;
gdjs.OverworldCode.GDDialogue3Objects1.length = 0;
gdjs.OverworldCode.GDDialogue3Objects2.length = 0;
gdjs.OverworldCode.GDDialogue3Objects3.length = 0;
gdjs.OverworldCode.GDDialogue3Objects4.length = 0;
gdjs.OverworldCode.GDEObjects1.length = 0;
gdjs.OverworldCode.GDEObjects2.length = 0;
gdjs.OverworldCode.GDEObjects3.length = 0;
gdjs.OverworldCode.GDEObjects4.length = 0;
gdjs.OverworldCode.GDE3Objects1.length = 0;
gdjs.OverworldCode.GDE3Objects2.length = 0;
gdjs.OverworldCode.GDE3Objects3.length = 0;
gdjs.OverworldCode.GDE3Objects4.length = 0;
gdjs.OverworldCode.GDE2Objects1.length = 0;
gdjs.OverworldCode.GDE2Objects2.length = 0;
gdjs.OverworldCode.GDE2Objects3.length = 0;
gdjs.OverworldCode.GDE2Objects4.length = 0;
gdjs.OverworldCode.GDYesButtonObjects1.length = 0;
gdjs.OverworldCode.GDYesButtonObjects2.length = 0;
gdjs.OverworldCode.GDYesButtonObjects3.length = 0;
gdjs.OverworldCode.GDYesButtonObjects4.length = 0;
gdjs.OverworldCode.GDNoButtonObjects1.length = 0;
gdjs.OverworldCode.GDNoButtonObjects2.length = 0;
gdjs.OverworldCode.GDNoButtonObjects3.length = 0;
gdjs.OverworldCode.GDNoButtonObjects4.length = 0;
gdjs.OverworldCode.GDChiChiTheBirdObjects1.length = 0;
gdjs.OverworldCode.GDChiChiTheBirdObjects2.length = 0;
gdjs.OverworldCode.GDChiChiTheBirdObjects3.length = 0;
gdjs.OverworldCode.GDChiChiTheBirdObjects4.length = 0;
gdjs.OverworldCode.GDFishermanObjects1.length = 0;
gdjs.OverworldCode.GDFishermanObjects2.length = 0;
gdjs.OverworldCode.GDFishermanObjects3.length = 0;
gdjs.OverworldCode.GDFishermanObjects4.length = 0;
gdjs.OverworldCode.GDTasksObjects1.length = 0;
gdjs.OverworldCode.GDTasksObjects2.length = 0;
gdjs.OverworldCode.GDTasksObjects3.length = 0;
gdjs.OverworldCode.GDTasksObjects4.length = 0;
gdjs.OverworldCode.GDRedFlowerObjects1.length = 0;
gdjs.OverworldCode.GDRedFlowerObjects2.length = 0;
gdjs.OverworldCode.GDRedFlowerObjects3.length = 0;
gdjs.OverworldCode.GDRedFlowerObjects4.length = 0;
gdjs.OverworldCode.GDLakeTroutObjects1.length = 0;
gdjs.OverworldCode.GDLakeTroutObjects2.length = 0;
gdjs.OverworldCode.GDLakeTroutObjects3.length = 0;
gdjs.OverworldCode.GDLakeTroutObjects4.length = 0;
gdjs.OverworldCode.GDFenceObjects1.length = 0;
gdjs.OverworldCode.GDFenceObjects2.length = 0;
gdjs.OverworldCode.GDFenceObjects3.length = 0;
gdjs.OverworldCode.GDFenceObjects4.length = 0;
gdjs.OverworldCode.GDfencepostObjects1.length = 0;
gdjs.OverworldCode.GDfencepostObjects2.length = 0;
gdjs.OverworldCode.GDfencepostObjects3.length = 0;
gdjs.OverworldCode.GDfencepostObjects4.length = 0;
gdjs.OverworldCode.GDMaleCharacter8Objects1.length = 0;
gdjs.OverworldCode.GDMaleCharacter8Objects2.length = 0;
gdjs.OverworldCode.GDMaleCharacter8Objects3.length = 0;
gdjs.OverworldCode.GDMaleCharacter8Objects4.length = 0;
gdjs.OverworldCode.GDBrownBackgroundObjects1.length = 0;
gdjs.OverworldCode.GDBrownBackgroundObjects2.length = 0;
gdjs.OverworldCode.GDBrownBackgroundObjects3.length = 0;
gdjs.OverworldCode.GDBrownBackgroundObjects4.length = 0;
gdjs.OverworldCode.GDNewSpriteObjects1.length = 0;
gdjs.OverworldCode.GDNewSpriteObjects2.length = 0;
gdjs.OverworldCode.GDNewSpriteObjects3.length = 0;
gdjs.OverworldCode.GDNewSpriteObjects4.length = 0;
gdjs.OverworldCode.GDNewSprite2Objects1.length = 0;
gdjs.OverworldCode.GDNewSprite2Objects2.length = 0;
gdjs.OverworldCode.GDNewSprite2Objects3.length = 0;
gdjs.OverworldCode.GDNewSprite2Objects4.length = 0;
gdjs.OverworldCode.GDNewSprite3Objects1.length = 0;
gdjs.OverworldCode.GDNewSprite3Objects2.length = 0;
gdjs.OverworldCode.GDNewSprite3Objects3.length = 0;
gdjs.OverworldCode.GDNewSprite3Objects4.length = 0;
gdjs.OverworldCode.GDCowObjects1.length = 0;
gdjs.OverworldCode.GDCowObjects2.length = 0;
gdjs.OverworldCode.GDCowObjects3.length = 0;
gdjs.OverworldCode.GDCowObjects4.length = 0;
gdjs.OverworldCode.GDBrownHorseObjects1.length = 0;
gdjs.OverworldCode.GDBrownHorseObjects2.length = 0;
gdjs.OverworldCode.GDBrownHorseObjects3.length = 0;
gdjs.OverworldCode.GDBrownHorseObjects4.length = 0;

gdjs.OverworldCode.eventsList26(runtimeScene);

return;

}

gdjs['OverworldCode'] = gdjs.OverworldCode;

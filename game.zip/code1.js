gdjs.BattleCode = {};
gdjs.BattleCode.GDAttack1Objects2_1final = [];

gdjs.BattleCode.GDAttack2Objects2_1final = [];

gdjs.BattleCode.GDEnemyObjects1_1final = [];

gdjs.BattleCode.GDPlayerObjects1_1final = [];

gdjs.BattleCode.GDRunObjects2_1final = [];

gdjs.BattleCode.GDTransitionObjects1= [];
gdjs.BattleCode.GDTransitionObjects2= [];
gdjs.BattleCode.GDTransitionObjects3= [];
gdjs.BattleCode.GDTransitionObjects4= [];
gdjs.BattleCode.GDTransitionObjects5= [];
gdjs.BattleCode.GDPlayerObjects1= [];
gdjs.BattleCode.GDPlayerObjects2= [];
gdjs.BattleCode.GDPlayerObjects3= [];
gdjs.BattleCode.GDPlayerObjects4= [];
gdjs.BattleCode.GDPlayerObjects5= [];
gdjs.BattleCode.GDDock1Objects1= [];
gdjs.BattleCode.GDDock1Objects2= [];
gdjs.BattleCode.GDDock1Objects3= [];
gdjs.BattleCode.GDDock1Objects4= [];
gdjs.BattleCode.GDDock1Objects5= [];
gdjs.BattleCode.GDFishermanObjects1= [];
gdjs.BattleCode.GDFishermanObjects2= [];
gdjs.BattleCode.GDFishermanObjects3= [];
gdjs.BattleCode.GDFishermanObjects4= [];
gdjs.BattleCode.GDFishermanObjects5= [];
gdjs.BattleCode.GDWater1Objects1= [];
gdjs.BattleCode.GDWater1Objects2= [];
gdjs.BattleCode.GDWater1Objects3= [];
gdjs.BattleCode.GDWater1Objects4= [];
gdjs.BattleCode.GDWater1Objects5= [];
gdjs.BattleCode.GDTextBorderObjects1= [];
gdjs.BattleCode.GDTextBorderObjects2= [];
gdjs.BattleCode.GDTextBorderObjects3= [];
gdjs.BattleCode.GDTextBorderObjects4= [];
gdjs.BattleCode.GDTextBorderObjects5= [];
gdjs.BattleCode.GDCollisionDetectObjects1= [];
gdjs.BattleCode.GDCollisionDetectObjects2= [];
gdjs.BattleCode.GDCollisionDetectObjects3= [];
gdjs.BattleCode.GDCollisionDetectObjects4= [];
gdjs.BattleCode.GDCollisionDetectObjects5= [];
gdjs.BattleCode.GDEObjects1= [];
gdjs.BattleCode.GDEObjects2= [];
gdjs.BattleCode.GDEObjects3= [];
gdjs.BattleCode.GDEObjects4= [];
gdjs.BattleCode.GDEObjects5= [];
gdjs.BattleCode.GDAObjects1= [];
gdjs.BattleCode.GDAObjects2= [];
gdjs.BattleCode.GDAObjects3= [];
gdjs.BattleCode.GDAObjects4= [];
gdjs.BattleCode.GDAObjects5= [];
gdjs.BattleCode.GDA2Objects1= [];
gdjs.BattleCode.GDA2Objects2= [];
gdjs.BattleCode.GDA2Objects3= [];
gdjs.BattleCode.GDA2Objects4= [];
gdjs.BattleCode.GDA2Objects5= [];
gdjs.BattleCode.GDDialogueObjects1= [];
gdjs.BattleCode.GDDialogueObjects2= [];
gdjs.BattleCode.GDDialogueObjects3= [];
gdjs.BattleCode.GDDialogueObjects4= [];
gdjs.BattleCode.GDDialogueObjects5= [];
gdjs.BattleCode.GDDialogue4Objects1= [];
gdjs.BattleCode.GDDialogue4Objects2= [];
gdjs.BattleCode.GDDialogue4Objects3= [];
gdjs.BattleCode.GDDialogue4Objects4= [];
gdjs.BattleCode.GDDialogue4Objects5= [];
gdjs.BattleCode.GDYesButtonObjects1= [];
gdjs.BattleCode.GDYesButtonObjects2= [];
gdjs.BattleCode.GDYesButtonObjects3= [];
gdjs.BattleCode.GDYesButtonObjects4= [];
gdjs.BattleCode.GDYesButtonObjects5= [];
gdjs.BattleCode.GDNoButtonObjects1= [];
gdjs.BattleCode.GDNoButtonObjects2= [];
gdjs.BattleCode.GDNoButtonObjects3= [];
gdjs.BattleCode.GDNoButtonObjects4= [];
gdjs.BattleCode.GDNoButtonObjects5= [];
gdjs.BattleCode.GDCornerWaterObjects1= [];
gdjs.BattleCode.GDCornerWaterObjects2= [];
gdjs.BattleCode.GDCornerWaterObjects3= [];
gdjs.BattleCode.GDCornerWaterObjects4= [];
gdjs.BattleCode.GDCornerWaterObjects5= [];
gdjs.BattleCode.GDWaterEdgeRightObjects1= [];
gdjs.BattleCode.GDWaterEdgeRightObjects2= [];
gdjs.BattleCode.GDWaterEdgeRightObjects3= [];
gdjs.BattleCode.GDWaterEdgeRightObjects4= [];
gdjs.BattleCode.GDWaterEdgeRightObjects5= [];
gdjs.BattleCode.GDNewTiledSpriteObjects1= [];
gdjs.BattleCode.GDNewTiledSpriteObjects2= [];
gdjs.BattleCode.GDNewTiledSpriteObjects3= [];
gdjs.BattleCode.GDNewTiledSpriteObjects4= [];
gdjs.BattleCode.GDNewTiledSpriteObjects5= [];
gdjs.BattleCode.GDGrassObjects1= [];
gdjs.BattleCode.GDGrassObjects2= [];
gdjs.BattleCode.GDGrassObjects3= [];
gdjs.BattleCode.GDGrassObjects4= [];
gdjs.BattleCode.GDGrassObjects5= [];
gdjs.BattleCode.GDTree2Objects1= [];
gdjs.BattleCode.GDTree2Objects2= [];
gdjs.BattleCode.GDTree2Objects3= [];
gdjs.BattleCode.GDTree2Objects4= [];
gdjs.BattleCode.GDTree2Objects5= [];
gdjs.BattleCode.GDNPC2Objects1= [];
gdjs.BattleCode.GDNPC2Objects2= [];
gdjs.BattleCode.GDNPC2Objects3= [];
gdjs.BattleCode.GDNPC2Objects4= [];
gdjs.BattleCode.GDNPC2Objects5= [];
gdjs.BattleCode.GDBush1Objects1= [];
gdjs.BattleCode.GDBush1Objects2= [];
gdjs.BattleCode.GDBush1Objects3= [];
gdjs.BattleCode.GDBush1Objects4= [];
gdjs.BattleCode.GDBush1Objects5= [];
gdjs.BattleCode.GDLakeTroutObjects1= [];
gdjs.BattleCode.GDLakeTroutObjects2= [];
gdjs.BattleCode.GDLakeTroutObjects3= [];
gdjs.BattleCode.GDLakeTroutObjects4= [];
gdjs.BattleCode.GDLakeTroutObjects5= [];
gdjs.BattleCode.GDEnemyObjects1= [];
gdjs.BattleCode.GDEnemyObjects2= [];
gdjs.BattleCode.GDEnemyObjects3= [];
gdjs.BattleCode.GDEnemyObjects4= [];
gdjs.BattleCode.GDEnemyObjects5= [];
gdjs.BattleCode.GDPlayerObjects1= [];
gdjs.BattleCode.GDPlayerObjects2= [];
gdjs.BattleCode.GDPlayerObjects3= [];
gdjs.BattleCode.GDPlayerObjects4= [];
gdjs.BattleCode.GDPlayerObjects5= [];
gdjs.BattleCode.GDPlayer_95HealthBarObjects1= [];
gdjs.BattleCode.GDPlayer_95HealthBarObjects2= [];
gdjs.BattleCode.GDPlayer_95HealthBarObjects3= [];
gdjs.BattleCode.GDPlayer_95HealthBarObjects4= [];
gdjs.BattleCode.GDPlayer_95HealthBarObjects5= [];
gdjs.BattleCode.GDEnemy_95HealthBarObjects1= [];
gdjs.BattleCode.GDEnemy_95HealthBarObjects2= [];
gdjs.BattleCode.GDEnemy_95HealthBarObjects3= [];
gdjs.BattleCode.GDEnemy_95HealthBarObjects4= [];
gdjs.BattleCode.GDEnemy_95HealthBarObjects5= [];
gdjs.BattleCode.GDHealthBorderObjects1= [];
gdjs.BattleCode.GDHealthBorderObjects2= [];
gdjs.BattleCode.GDHealthBorderObjects3= [];
gdjs.BattleCode.GDHealthBorderObjects4= [];
gdjs.BattleCode.GDHealthBorderObjects5= [];
gdjs.BattleCode.GDDialogueObjects1= [];
gdjs.BattleCode.GDDialogueObjects2= [];
gdjs.BattleCode.GDDialogueObjects3= [];
gdjs.BattleCode.GDDialogueObjects4= [];
gdjs.BattleCode.GDDialogueObjects5= [];
gdjs.BattleCode.GDNewButtonObjects1= [];
gdjs.BattleCode.GDNewButtonObjects2= [];
gdjs.BattleCode.GDNewButtonObjects3= [];
gdjs.BattleCode.GDNewButtonObjects4= [];
gdjs.BattleCode.GDNewButtonObjects5= [];
gdjs.BattleCode.GDGrassObjects1= [];
gdjs.BattleCode.GDGrassObjects2= [];
gdjs.BattleCode.GDGrassObjects3= [];
gdjs.BattleCode.GDGrassObjects4= [];
gdjs.BattleCode.GDGrassObjects5= [];
gdjs.BattleCode.GDHouse2Objects1= [];
gdjs.BattleCode.GDHouse2Objects2= [];
gdjs.BattleCode.GDHouse2Objects3= [];
gdjs.BattleCode.GDHouse2Objects4= [];
gdjs.BattleCode.GDHouse2Objects5= [];
gdjs.BattleCode.GDAttack1Objects1= [];
gdjs.BattleCode.GDAttack1Objects2= [];
gdjs.BattleCode.GDAttack1Objects3= [];
gdjs.BattleCode.GDAttack1Objects4= [];
gdjs.BattleCode.GDAttack1Objects5= [];
gdjs.BattleCode.GDAttack2Objects1= [];
gdjs.BattleCode.GDAttack2Objects2= [];
gdjs.BattleCode.GDAttack2Objects3= [];
gdjs.BattleCode.GDAttack2Objects4= [];
gdjs.BattleCode.GDAttack2Objects5= [];
gdjs.BattleCode.GDRunObjects1= [];
gdjs.BattleCode.GDRunObjects2= [];
gdjs.BattleCode.GDRunObjects3= [];
gdjs.BattleCode.GDRunObjects4= [];
gdjs.BattleCode.GDRunObjects5= [];
gdjs.BattleCode.GDBackgroundObjects1= [];
gdjs.BattleCode.GDBackgroundObjects2= [];
gdjs.BattleCode.GDBackgroundObjects3= [];
gdjs.BattleCode.GDBackgroundObjects4= [];
gdjs.BattleCode.GDBackgroundObjects5= [];

gdjs.BattleCode.conditionTrue_0 = {val:false};
gdjs.BattleCode.condition0IsTrue_0 = {val:false};
gdjs.BattleCode.condition1IsTrue_0 = {val:false};
gdjs.BattleCode.condition2IsTrue_0 = {val:false};
gdjs.BattleCode.condition3IsTrue_0 = {val:false};
gdjs.BattleCode.conditionTrue_1 = {val:false};
gdjs.BattleCode.condition0IsTrue_1 = {val:false};
gdjs.BattleCode.condition1IsTrue_1 = {val:false};
gdjs.BattleCode.condition2IsTrue_1 = {val:false};
gdjs.BattleCode.condition3IsTrue_1 = {val:false};


gdjs.BattleCode.eventsList0 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.BattleCode.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Enemy_HealthBar"), gdjs.BattleCode.GDEnemy_95HealthBarObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.BattleCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player_HealthBar"), gdjs.BattleCode.GDPlayer_95HealthBarObjects1);
{for(var i = 0, len = gdjs.BattleCode.GDPlayer_95HealthBarObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDPlayer_95HealthBarObjects1[i].setWidth(448 * ((( gdjs.BattleCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.BattleCode.GDPlayerObjects1[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.BattleCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.BattleCode.GDPlayerObjects1[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))));
}
}{for(var i = 0, len = gdjs.BattleCode.GDEnemy_95HealthBarObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDEnemy_95HealthBarObjects1[i].setWidth(448 * ((( gdjs.BattleCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.BattleCode.GDEnemyObjects1[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.BattleCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.BattleCode.GDEnemyObjects1[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))));
}
}}

}


};gdjs.BattleCode.asyncCallback15675316 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Enemy"), gdjs.BattleCode.GDEnemyObjects4);

{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().get("Turn"));
}{for(var i = 0, len = gdjs.BattleCode.GDEnemyObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDEnemyObjects4[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0, -(4), -(4), 0, 2, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
gdjs.BattleCode.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.BattleCode.GDEnemyObjects3) asyncObjectsList.addObject("Enemy", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.BattleCode.asyncCallback15675316(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.BattleCode.asyncCallback15675220 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.BattleCode.GDDialogueObjects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.BattleCode.GDEnemyObjects3);
{gdjs.evtTools.sound.playSound(runtimeScene, "Attack.wav", false, 90, gdjs.randomFloatInRange(0.9, 1));
}{for(var i = 0, len = gdjs.BattleCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDEnemyObjects3[i].getBehavior("ShakeObject_PositionAngle").StopShaking((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.BattleCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDEnemyObjects3[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.6, 10, 10, 5, 10, 0.2, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.BattleCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDEnemyObjects3[i].getBehavior("Flash").Flash(0.3, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.BattleCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDEnemyObjects3[i].getBehavior("Health").Hit(10, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.BattleCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDDialogueObjects3[i].setText("You attacked your enemy.");
}
}
{ //Subevents
gdjs.BattleCode.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.BattleCode.eventsList2 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.BattleCode.asyncCallback15675220(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.BattleCode.asyncCallback15674572 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.BattleCode.GDPlayerObjects2);

{for(var i = 0, len = gdjs.BattleCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDPlayerObjects2[i].getBehavior("Tween").addObjectPositionTween("BackUp", (gdjs.BattleCode.GDPlayerObjects2[i].getPointX("")) + 100, (gdjs.BattleCode.GDPlayerObjects2[i].getPointY("")), "easeInQuad", 100, false);
}
}
{ //Subevents
gdjs.BattleCode.eventsList2(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.BattleCode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.BattleCode.GDPlayerObjects1) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.BattleCode.asyncCallback15674572(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.BattleCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Attack1"), gdjs.BattleCode.GDAttack1Objects1);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDAttack1Objects1.length;i<l;++i) {
    if ( gdjs.BattleCode.GDAttack1Objects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDAttack1Objects1[k] = gdjs.BattleCode.GDAttack1Objects1[i];
        ++k;
    }
}
gdjs.BattleCode.GDAttack1Objects1.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.BattleCode.GDPlayerObjects1);
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().get("Clickable"));
}{for(var i = 0, len = gdjs.BattleCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDPlayerObjects1[i].getBehavior("Tween").addObjectPositionTween("BackUp", (gdjs.BattleCode.GDPlayerObjects1[i].getPointX("")) - 100, (gdjs.BattleCode.GDPlayerObjects1[i].getPointY("")), "easeOutQuad", 500, false);
}
}
{ //Subevents
gdjs.BattleCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.eventsList5 = function(runtimeScene) {

{

gdjs.BattleCode.GDAttack1Objects2.length = 0;

gdjs.BattleCode.GDAttack2Objects2.length = 0;

gdjs.BattleCode.GDRunObjects2.length = 0;


gdjs.BattleCode.condition0IsTrue_0.val = false;
gdjs.BattleCode.condition1IsTrue_0.val = false;
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition0IsTrue_0;
gdjs.BattleCode.GDAttack1Objects2_1final.length = 0;gdjs.BattleCode.GDAttack2Objects2_1final.length = 0;gdjs.BattleCode.GDRunObjects2_1final.length = 0;gdjs.BattleCode.condition0IsTrue_1.val = false;
gdjs.BattleCode.condition1IsTrue_1.val = false;
gdjs.BattleCode.condition2IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Attack1"), gdjs.BattleCode.GDAttack1Objects3);
for(var i = 0, k = 0, l = gdjs.BattleCode.GDAttack1Objects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDAttack1Objects3[i].IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDAttack1Objects3[k] = gdjs.BattleCode.GDAttack1Objects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDAttack1Objects3.length = k;if( gdjs.BattleCode.condition0IsTrue_1.val ) {
    gdjs.BattleCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.BattleCode.GDAttack1Objects3.length;j<jLen;++j) {
        if ( gdjs.BattleCode.GDAttack1Objects2_1final.indexOf(gdjs.BattleCode.GDAttack1Objects3[j]) === -1 )
            gdjs.BattleCode.GDAttack1Objects2_1final.push(gdjs.BattleCode.GDAttack1Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Attack2"), gdjs.BattleCode.GDAttack2Objects3);
for(var i = 0, k = 0, l = gdjs.BattleCode.GDAttack2Objects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDAttack2Objects3[i].IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDAttack2Objects3[k] = gdjs.BattleCode.GDAttack2Objects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDAttack2Objects3.length = k;if( gdjs.BattleCode.condition1IsTrue_1.val ) {
    gdjs.BattleCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.BattleCode.GDAttack2Objects3.length;j<jLen;++j) {
        if ( gdjs.BattleCode.GDAttack2Objects2_1final.indexOf(gdjs.BattleCode.GDAttack2Objects3[j]) === -1 )
            gdjs.BattleCode.GDAttack2Objects2_1final.push(gdjs.BattleCode.GDAttack2Objects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Run"), gdjs.BattleCode.GDRunObjects3);
for(var i = 0, k = 0, l = gdjs.BattleCode.GDRunObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDRunObjects3[i].IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.BattleCode.condition2IsTrue_1.val = true;
        gdjs.BattleCode.GDRunObjects3[k] = gdjs.BattleCode.GDRunObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDRunObjects3.length = k;if( gdjs.BattleCode.condition2IsTrue_1.val ) {
    gdjs.BattleCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.BattleCode.GDRunObjects3.length;j<jLen;++j) {
        if ( gdjs.BattleCode.GDRunObjects2_1final.indexOf(gdjs.BattleCode.GDRunObjects3[j]) === -1 )
            gdjs.BattleCode.GDRunObjects2_1final.push(gdjs.BattleCode.GDRunObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.BattleCode.GDAttack1Objects2_1final, gdjs.BattleCode.GDAttack1Objects2);
gdjs.copyArray(gdjs.BattleCode.GDAttack2Objects2_1final, gdjs.BattleCode.GDAttack2Objects2);
gdjs.copyArray(gdjs.BattleCode.GDRunObjects2_1final, gdjs.BattleCode.GDRunObjects2);
}
}
}if ( gdjs.BattleCode.condition0IsTrue_0.val ) {
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition1IsTrue_0;
gdjs.BattleCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15672364);
}
}}
if (gdjs.BattleCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "HoverSound.wav", false, 20, gdjs.randomFloatInRange(0.8, 0.9));
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
gdjs.BattleCode.condition1IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("Turn"), false);
}if ( gdjs.BattleCode.condition0IsTrue_0.val ) {
{
gdjs.BattleCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("Clickable"), false);
}}
if (gdjs.BattleCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.asyncCallback15681356 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.BattleCode.GDPlayerObjects5);

{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().get("Turn"));
}{for(var i = 0, len = gdjs.BattleCode.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDPlayerObjects5[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0, 5, 5, 0, 2, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().get("Clickable"));
}}
gdjs.BattleCode.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.BattleCode.GDPlayerObjects4) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.BattleCode.asyncCallback15681356(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.BattleCode.asyncCallback15678924 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.BattleCode.GDDialogueObjects4);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.BattleCode.GDPlayerObjects4);
{gdjs.evtTools.sound.playSound(runtimeScene, "Attack.wav", false, 90, gdjs.randomFloatInRange(0.9, 1));
}{for(var i = 0, len = gdjs.BattleCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDPlayerObjects4[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.6, 10, 10, 5, 10, 0.2, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.BattleCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDPlayerObjects4[i].getBehavior("Flash").Flash(0.3, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.BattleCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDPlayerObjects4[i].getBehavior("Health").Hit(10, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.BattleCode.GDDialogueObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDDialogueObjects4[i].setText("Your enemy attacked you.");
}
}
{ //Subevents
gdjs.BattleCode.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.BattleCode.eventsList7 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.BattleCode.asyncCallback15678924(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.BattleCode.asyncCallback15679116 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Enemy"), gdjs.BattleCode.GDEnemyObjects3);

{for(var i = 0, len = gdjs.BattleCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDEnemyObjects3[i].getBehavior("Tween").addObjectPositionTween("BackUp", (gdjs.BattleCode.GDEnemyObjects3[i].getPointX("")) - 100, (gdjs.BattleCode.GDEnemyObjects3[i].getPointY("")), "easeInQuad", 100, false);
}
}
{ //Subevents
gdjs.BattleCode.eventsList7(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.BattleCode.eventsList8 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.BattleCode.GDEnemyObjects2) asyncObjectsList.addObject("Enemy", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.BattleCode.asyncCallback15679116(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.BattleCode.asyncCallback15678828 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.BattleCode.GDEnemyObjects2);
{for(var i = 0, len = gdjs.BattleCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDEnemyObjects2[i].getBehavior("Tween").addObjectPositionTween("BackUp", (gdjs.BattleCode.GDEnemyObjects2[i].getPointX("")) + 100, (gdjs.BattleCode.GDEnemyObjects2[i].getPointY("")), "easeOutQuad", 500, false);
}
}
{ //Subevents
gdjs.BattleCode.eventsList8(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.BattleCode.eventsList9 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.BattleCode.asyncCallback15678828(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.BattleCode.eventsList10 = function(runtimeScene) {

{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition0IsTrue_0;
gdjs.BattleCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15678668);
}
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.eventsList11 = function(runtimeScene) {

{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("Turn"), true);
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.eventsList12 = function(runtimeScene) {

{

gdjs.BattleCode.GDEnemyObjects1.length = 0;

gdjs.BattleCode.GDPlayerObjects1.length = 0;


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition0IsTrue_0;
gdjs.BattleCode.GDEnemyObjects1_1final.length = 0;gdjs.BattleCode.GDPlayerObjects1_1final.length = 0;gdjs.BattleCode.condition0IsTrue_1.val = false;
gdjs.BattleCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.BattleCode.GDEnemyObjects2);
for(var i = 0, k = 0, l = gdjs.BattleCode.GDEnemyObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDEnemyObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDEnemyObjects2[k] = gdjs.BattleCode.GDEnemyObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDEnemyObjects2.length = k;if( gdjs.BattleCode.condition0IsTrue_1.val ) {
    gdjs.BattleCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.BattleCode.GDEnemyObjects2.length;j<jLen;++j) {
        if ( gdjs.BattleCode.GDEnemyObjects1_1final.indexOf(gdjs.BattleCode.GDEnemyObjects2[j]) === -1 )
            gdjs.BattleCode.GDEnemyObjects1_1final.push(gdjs.BattleCode.GDEnemyObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.BattleCode.GDPlayerObjects2);
for(var i = 0, k = 0, l = gdjs.BattleCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDPlayerObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDPlayerObjects2[k] = gdjs.BattleCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDPlayerObjects2.length = k;if( gdjs.BattleCode.condition1IsTrue_1.val ) {
    gdjs.BattleCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.BattleCode.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.BattleCode.GDPlayerObjects1_1final.indexOf(gdjs.BattleCode.GDPlayerObjects2[j]) === -1 )
            gdjs.BattleCode.GDPlayerObjects1_1final.push(gdjs.BattleCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.BattleCode.GDEnemyObjects1_1final, gdjs.BattleCode.GDEnemyObjects1);
gdjs.copyArray(gdjs.BattleCode.GDPlayerObjects1_1final, gdjs.BattleCode.GDPlayerObjects1);
}
}
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


};gdjs.BattleCode.eventsList13 = function(runtimeScene) {

{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.BattleCode.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Grass"), gdjs.BattleCode.GDGrassObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.BattleCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Transition"), gdjs.BattleCode.GDTransitionObjects1);
{for(var i = 0, len = gdjs.BattleCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDTransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.5, "Circular", "Backward", 255, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.BattleCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDPlayerObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0, 5, 5, 0, 2, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.BattleCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDEnemyObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0, -(4), -(4), 0, 2, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 10, "Background", 0);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.BattleCode.GDGrassObjects1.length !== 0 ? gdjs.BattleCode.GDGrassObjects1[0] : null), true, "Background", 0);
}}

}


{


gdjs.BattleCode.eventsList0(runtimeScene);
}


{


gdjs.BattleCode.eventsList5(runtimeScene);
}


{


gdjs.BattleCode.eventsList11(runtimeScene);
}


{


gdjs.BattleCode.eventsList12(runtimeScene);
}


};

gdjs.BattleCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.BattleCode.GDTransitionObjects1.length = 0;
gdjs.BattleCode.GDTransitionObjects2.length = 0;
gdjs.BattleCode.GDTransitionObjects3.length = 0;
gdjs.BattleCode.GDTransitionObjects4.length = 0;
gdjs.BattleCode.GDTransitionObjects5.length = 0;
gdjs.BattleCode.GDPlayerObjects1.length = 0;
gdjs.BattleCode.GDPlayerObjects2.length = 0;
gdjs.BattleCode.GDPlayerObjects3.length = 0;
gdjs.BattleCode.GDPlayerObjects4.length = 0;
gdjs.BattleCode.GDPlayerObjects5.length = 0;
gdjs.BattleCode.GDDock1Objects1.length = 0;
gdjs.BattleCode.GDDock1Objects2.length = 0;
gdjs.BattleCode.GDDock1Objects3.length = 0;
gdjs.BattleCode.GDDock1Objects4.length = 0;
gdjs.BattleCode.GDDock1Objects5.length = 0;
gdjs.BattleCode.GDFishermanObjects1.length = 0;
gdjs.BattleCode.GDFishermanObjects2.length = 0;
gdjs.BattleCode.GDFishermanObjects3.length = 0;
gdjs.BattleCode.GDFishermanObjects4.length = 0;
gdjs.BattleCode.GDFishermanObjects5.length = 0;
gdjs.BattleCode.GDWater1Objects1.length = 0;
gdjs.BattleCode.GDWater1Objects2.length = 0;
gdjs.BattleCode.GDWater1Objects3.length = 0;
gdjs.BattleCode.GDWater1Objects4.length = 0;
gdjs.BattleCode.GDWater1Objects5.length = 0;
gdjs.BattleCode.GDTextBorderObjects1.length = 0;
gdjs.BattleCode.GDTextBorderObjects2.length = 0;
gdjs.BattleCode.GDTextBorderObjects3.length = 0;
gdjs.BattleCode.GDTextBorderObjects4.length = 0;
gdjs.BattleCode.GDTextBorderObjects5.length = 0;
gdjs.BattleCode.GDCollisionDetectObjects1.length = 0;
gdjs.BattleCode.GDCollisionDetectObjects2.length = 0;
gdjs.BattleCode.GDCollisionDetectObjects3.length = 0;
gdjs.BattleCode.GDCollisionDetectObjects4.length = 0;
gdjs.BattleCode.GDCollisionDetectObjects5.length = 0;
gdjs.BattleCode.GDEObjects1.length = 0;
gdjs.BattleCode.GDEObjects2.length = 0;
gdjs.BattleCode.GDEObjects3.length = 0;
gdjs.BattleCode.GDEObjects4.length = 0;
gdjs.BattleCode.GDEObjects5.length = 0;
gdjs.BattleCode.GDAObjects1.length = 0;
gdjs.BattleCode.GDAObjects2.length = 0;
gdjs.BattleCode.GDAObjects3.length = 0;
gdjs.BattleCode.GDAObjects4.length = 0;
gdjs.BattleCode.GDAObjects5.length = 0;
gdjs.BattleCode.GDA2Objects1.length = 0;
gdjs.BattleCode.GDA2Objects2.length = 0;
gdjs.BattleCode.GDA2Objects3.length = 0;
gdjs.BattleCode.GDA2Objects4.length = 0;
gdjs.BattleCode.GDA2Objects5.length = 0;
gdjs.BattleCode.GDDialogueObjects1.length = 0;
gdjs.BattleCode.GDDialogueObjects2.length = 0;
gdjs.BattleCode.GDDialogueObjects3.length = 0;
gdjs.BattleCode.GDDialogueObjects4.length = 0;
gdjs.BattleCode.GDDialogueObjects5.length = 0;
gdjs.BattleCode.GDDialogue4Objects1.length = 0;
gdjs.BattleCode.GDDialogue4Objects2.length = 0;
gdjs.BattleCode.GDDialogue4Objects3.length = 0;
gdjs.BattleCode.GDDialogue4Objects4.length = 0;
gdjs.BattleCode.GDDialogue4Objects5.length = 0;
gdjs.BattleCode.GDYesButtonObjects1.length = 0;
gdjs.BattleCode.GDYesButtonObjects2.length = 0;
gdjs.BattleCode.GDYesButtonObjects3.length = 0;
gdjs.BattleCode.GDYesButtonObjects4.length = 0;
gdjs.BattleCode.GDYesButtonObjects5.length = 0;
gdjs.BattleCode.GDNoButtonObjects1.length = 0;
gdjs.BattleCode.GDNoButtonObjects2.length = 0;
gdjs.BattleCode.GDNoButtonObjects3.length = 0;
gdjs.BattleCode.GDNoButtonObjects4.length = 0;
gdjs.BattleCode.GDNoButtonObjects5.length = 0;
gdjs.BattleCode.GDCornerWaterObjects1.length = 0;
gdjs.BattleCode.GDCornerWaterObjects2.length = 0;
gdjs.BattleCode.GDCornerWaterObjects3.length = 0;
gdjs.BattleCode.GDCornerWaterObjects4.length = 0;
gdjs.BattleCode.GDCornerWaterObjects5.length = 0;
gdjs.BattleCode.GDWaterEdgeRightObjects1.length = 0;
gdjs.BattleCode.GDWaterEdgeRightObjects2.length = 0;
gdjs.BattleCode.GDWaterEdgeRightObjects3.length = 0;
gdjs.BattleCode.GDWaterEdgeRightObjects4.length = 0;
gdjs.BattleCode.GDWaterEdgeRightObjects5.length = 0;
gdjs.BattleCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.BattleCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.BattleCode.GDNewTiledSpriteObjects3.length = 0;
gdjs.BattleCode.GDNewTiledSpriteObjects4.length = 0;
gdjs.BattleCode.GDNewTiledSpriteObjects5.length = 0;
gdjs.BattleCode.GDGrassObjects1.length = 0;
gdjs.BattleCode.GDGrassObjects2.length = 0;
gdjs.BattleCode.GDGrassObjects3.length = 0;
gdjs.BattleCode.GDGrassObjects4.length = 0;
gdjs.BattleCode.GDGrassObjects5.length = 0;
gdjs.BattleCode.GDTree2Objects1.length = 0;
gdjs.BattleCode.GDTree2Objects2.length = 0;
gdjs.BattleCode.GDTree2Objects3.length = 0;
gdjs.BattleCode.GDTree2Objects4.length = 0;
gdjs.BattleCode.GDTree2Objects5.length = 0;
gdjs.BattleCode.GDNPC2Objects1.length = 0;
gdjs.BattleCode.GDNPC2Objects2.length = 0;
gdjs.BattleCode.GDNPC2Objects3.length = 0;
gdjs.BattleCode.GDNPC2Objects4.length = 0;
gdjs.BattleCode.GDNPC2Objects5.length = 0;
gdjs.BattleCode.GDBush1Objects1.length = 0;
gdjs.BattleCode.GDBush1Objects2.length = 0;
gdjs.BattleCode.GDBush1Objects3.length = 0;
gdjs.BattleCode.GDBush1Objects4.length = 0;
gdjs.BattleCode.GDBush1Objects5.length = 0;
gdjs.BattleCode.GDLakeTroutObjects1.length = 0;
gdjs.BattleCode.GDLakeTroutObjects2.length = 0;
gdjs.BattleCode.GDLakeTroutObjects3.length = 0;
gdjs.BattleCode.GDLakeTroutObjects4.length = 0;
gdjs.BattleCode.GDLakeTroutObjects5.length = 0;
gdjs.BattleCode.GDEnemyObjects1.length = 0;
gdjs.BattleCode.GDEnemyObjects2.length = 0;
gdjs.BattleCode.GDEnemyObjects3.length = 0;
gdjs.BattleCode.GDEnemyObjects4.length = 0;
gdjs.BattleCode.GDEnemyObjects5.length = 0;
gdjs.BattleCode.GDPlayerObjects1.length = 0;
gdjs.BattleCode.GDPlayerObjects2.length = 0;
gdjs.BattleCode.GDPlayerObjects3.length = 0;
gdjs.BattleCode.GDPlayerObjects4.length = 0;
gdjs.BattleCode.GDPlayerObjects5.length = 0;
gdjs.BattleCode.GDPlayer_95HealthBarObjects1.length = 0;
gdjs.BattleCode.GDPlayer_95HealthBarObjects2.length = 0;
gdjs.BattleCode.GDPlayer_95HealthBarObjects3.length = 0;
gdjs.BattleCode.GDPlayer_95HealthBarObjects4.length = 0;
gdjs.BattleCode.GDPlayer_95HealthBarObjects5.length = 0;
gdjs.BattleCode.GDEnemy_95HealthBarObjects1.length = 0;
gdjs.BattleCode.GDEnemy_95HealthBarObjects2.length = 0;
gdjs.BattleCode.GDEnemy_95HealthBarObjects3.length = 0;
gdjs.BattleCode.GDEnemy_95HealthBarObjects4.length = 0;
gdjs.BattleCode.GDEnemy_95HealthBarObjects5.length = 0;
gdjs.BattleCode.GDHealthBorderObjects1.length = 0;
gdjs.BattleCode.GDHealthBorderObjects2.length = 0;
gdjs.BattleCode.GDHealthBorderObjects3.length = 0;
gdjs.BattleCode.GDHealthBorderObjects4.length = 0;
gdjs.BattleCode.GDHealthBorderObjects5.length = 0;
gdjs.BattleCode.GDDialogueObjects1.length = 0;
gdjs.BattleCode.GDDialogueObjects2.length = 0;
gdjs.BattleCode.GDDialogueObjects3.length = 0;
gdjs.BattleCode.GDDialogueObjects4.length = 0;
gdjs.BattleCode.GDDialogueObjects5.length = 0;
gdjs.BattleCode.GDNewButtonObjects1.length = 0;
gdjs.BattleCode.GDNewButtonObjects2.length = 0;
gdjs.BattleCode.GDNewButtonObjects3.length = 0;
gdjs.BattleCode.GDNewButtonObjects4.length = 0;
gdjs.BattleCode.GDNewButtonObjects5.length = 0;
gdjs.BattleCode.GDGrassObjects1.length = 0;
gdjs.BattleCode.GDGrassObjects2.length = 0;
gdjs.BattleCode.GDGrassObjects3.length = 0;
gdjs.BattleCode.GDGrassObjects4.length = 0;
gdjs.BattleCode.GDGrassObjects5.length = 0;
gdjs.BattleCode.GDHouse2Objects1.length = 0;
gdjs.BattleCode.GDHouse2Objects2.length = 0;
gdjs.BattleCode.GDHouse2Objects3.length = 0;
gdjs.BattleCode.GDHouse2Objects4.length = 0;
gdjs.BattleCode.GDHouse2Objects5.length = 0;
gdjs.BattleCode.GDAttack1Objects1.length = 0;
gdjs.BattleCode.GDAttack1Objects2.length = 0;
gdjs.BattleCode.GDAttack1Objects3.length = 0;
gdjs.BattleCode.GDAttack1Objects4.length = 0;
gdjs.BattleCode.GDAttack1Objects5.length = 0;
gdjs.BattleCode.GDAttack2Objects1.length = 0;
gdjs.BattleCode.GDAttack2Objects2.length = 0;
gdjs.BattleCode.GDAttack2Objects3.length = 0;
gdjs.BattleCode.GDAttack2Objects4.length = 0;
gdjs.BattleCode.GDAttack2Objects5.length = 0;
gdjs.BattleCode.GDRunObjects1.length = 0;
gdjs.BattleCode.GDRunObjects2.length = 0;
gdjs.BattleCode.GDRunObjects3.length = 0;
gdjs.BattleCode.GDRunObjects4.length = 0;
gdjs.BattleCode.GDRunObjects5.length = 0;
gdjs.BattleCode.GDBackgroundObjects1.length = 0;
gdjs.BattleCode.GDBackgroundObjects2.length = 0;
gdjs.BattleCode.GDBackgroundObjects3.length = 0;
gdjs.BattleCode.GDBackgroundObjects4.length = 0;
gdjs.BattleCode.GDBackgroundObjects5.length = 0;

gdjs.BattleCode.eventsList13(runtimeScene);

return;

}

gdjs['BattleCode'] = gdjs.BattleCode;

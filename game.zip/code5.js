gdjs.TreeCompleteCode = {};

gdjs.TreeCompleteCode.conditionTrue_0 = {val:false};
gdjs.TreeCompleteCode.condition0IsTrue_0 = {val:false};


gdjs.TreeCompleteCode.eventsList0 = function(runtimeScene) {

};

gdjs.TreeCompleteCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.TreeCompleteCode.eventsList0(runtimeScene);

return;

}

gdjs['TreeCompleteCode'] = gdjs.TreeCompleteCode;

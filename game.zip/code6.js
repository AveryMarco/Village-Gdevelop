gdjs.QuestCode = {};
gdjs.QuestCode.GDTransitionObjects1= [];
gdjs.QuestCode.GDTransitionObjects2= [];
gdjs.QuestCode.GDTransitionObjects3= [];
gdjs.QuestCode.GDPlayerObjects1= [];
gdjs.QuestCode.GDPlayerObjects2= [];
gdjs.QuestCode.GDPlayerObjects3= [];
gdjs.QuestCode.GDDock1Objects1= [];
gdjs.QuestCode.GDDock1Objects2= [];
gdjs.QuestCode.GDDock1Objects3= [];
gdjs.QuestCode.GDFishermanObjects1= [];
gdjs.QuestCode.GDFishermanObjects2= [];
gdjs.QuestCode.GDFishermanObjects3= [];
gdjs.QuestCode.GDWater1Objects1= [];
gdjs.QuestCode.GDWater1Objects2= [];
gdjs.QuestCode.GDWater1Objects3= [];
gdjs.QuestCode.GDTextBorderObjects1= [];
gdjs.QuestCode.GDTextBorderObjects2= [];
gdjs.QuestCode.GDTextBorderObjects3= [];
gdjs.QuestCode.GDCollisionDetectObjects1= [];
gdjs.QuestCode.GDCollisionDetectObjects2= [];
gdjs.QuestCode.GDCollisionDetectObjects3= [];
gdjs.QuestCode.GDEObjects1= [];
gdjs.QuestCode.GDEObjects2= [];
gdjs.QuestCode.GDEObjects3= [];
gdjs.QuestCode.GDAObjects1= [];
gdjs.QuestCode.GDAObjects2= [];
gdjs.QuestCode.GDAObjects3= [];
gdjs.QuestCode.GDA2Objects1= [];
gdjs.QuestCode.GDA2Objects2= [];
gdjs.QuestCode.GDA2Objects3= [];
gdjs.QuestCode.GDDialogueObjects1= [];
gdjs.QuestCode.GDDialogueObjects2= [];
gdjs.QuestCode.GDDialogueObjects3= [];
gdjs.QuestCode.GDDialogue4Objects1= [];
gdjs.QuestCode.GDDialogue4Objects2= [];
gdjs.QuestCode.GDDialogue4Objects3= [];
gdjs.QuestCode.GDYesButtonObjects1= [];
gdjs.QuestCode.GDYesButtonObjects2= [];
gdjs.QuestCode.GDYesButtonObjects3= [];
gdjs.QuestCode.GDNoButtonObjects1= [];
gdjs.QuestCode.GDNoButtonObjects2= [];
gdjs.QuestCode.GDNoButtonObjects3= [];
gdjs.QuestCode.GDCornerWaterObjects1= [];
gdjs.QuestCode.GDCornerWaterObjects2= [];
gdjs.QuestCode.GDCornerWaterObjects3= [];
gdjs.QuestCode.GDWaterEdgeRightObjects1= [];
gdjs.QuestCode.GDWaterEdgeRightObjects2= [];
gdjs.QuestCode.GDWaterEdgeRightObjects3= [];
gdjs.QuestCode.GDNewTiledSpriteObjects1= [];
gdjs.QuestCode.GDNewTiledSpriteObjects2= [];
gdjs.QuestCode.GDNewTiledSpriteObjects3= [];
gdjs.QuestCode.GDGrassObjects1= [];
gdjs.QuestCode.GDGrassObjects2= [];
gdjs.QuestCode.GDGrassObjects3= [];
gdjs.QuestCode.GDTree2Objects1= [];
gdjs.QuestCode.GDTree2Objects2= [];
gdjs.QuestCode.GDTree2Objects3= [];
gdjs.QuestCode.GDNPC2Objects1= [];
gdjs.QuestCode.GDNPC2Objects2= [];
gdjs.QuestCode.GDNPC2Objects3= [];
gdjs.QuestCode.GDBush1Objects1= [];
gdjs.QuestCode.GDBush1Objects2= [];
gdjs.QuestCode.GDBush1Objects3= [];
gdjs.QuestCode.GDLakeTroutObjects1= [];
gdjs.QuestCode.GDLakeTroutObjects2= [];
gdjs.QuestCode.GDLakeTroutObjects3= [];
gdjs.QuestCode.GDRock1Objects1= [];
gdjs.QuestCode.GDRock1Objects2= [];
gdjs.QuestCode.GDRock1Objects3= [];
gdjs.QuestCode.GDDogObjects1= [];
gdjs.QuestCode.GDDogObjects2= [];
gdjs.QuestCode.GDDogObjects3= [];
gdjs.QuestCode.GDMushroomObjects1= [];
gdjs.QuestCode.GDMushroomObjects2= [];
gdjs.QuestCode.GDMushroomObjects3= [];

gdjs.QuestCode.conditionTrue_0 = {val:false};
gdjs.QuestCode.condition0IsTrue_0 = {val:false};
gdjs.QuestCode.condition1IsTrue_0 = {val:false};
gdjs.QuestCode.condition2IsTrue_0 = {val:false};
gdjs.QuestCode.conditionTrue_1 = {val:false};
gdjs.QuestCode.condition0IsTrue_1 = {val:false};
gdjs.QuestCode.condition1IsTrue_1 = {val:false};
gdjs.QuestCode.condition2IsTrue_1 = {val:false};


gdjs.QuestCode.mapOfGDgdjs_46QuestCode_46GDCollisionDetectObjects1Objects = Hashtable.newFrom({"CollisionDetect": gdjs.QuestCode.GDCollisionDetectObjects1});
gdjs.QuestCode.eventsList0 = function(runtimeScene) {

};gdjs.QuestCode.eventsList1 = function(runtimeScene) {

{


gdjs.QuestCode.condition0IsTrue_0.val = false;
{
{gdjs.QuestCode.conditionTrue_1 = gdjs.QuestCode.condition0IsTrue_0;
gdjs.QuestCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15821428);
}
}if (gdjs.QuestCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("E"), gdjs.QuestCode.GDEObjects2);
gdjs.copyArray(runtimeScene.getObjects("NoButton"), gdjs.QuestCode.GDNoButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.QuestCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("YesButton"), gdjs.QuestCode.GDYesButtonObjects2);
{for(var i = 0, len = gdjs.QuestCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.QuestCode.GDPlayerObjects2[i].activateBehavior("TopDownMovement", true);
}
}{for(var i = 0, len = gdjs.QuestCode.GDEObjects2.length ;i < len;++i) {
    gdjs.QuestCode.GDEObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.QuestCode.GDYesButtonObjects2.length ;i < len;++i) {
    gdjs.QuestCode.GDYesButtonObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.QuestCode.GDNoButtonObjects2.length ;i < len;++i) {
    gdjs.QuestCode.GDNoButtonObjects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.QuestCode.GDPlayerObjects2);

gdjs.QuestCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.QuestCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.QuestCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isUsingControl("Up") ) {
        gdjs.QuestCode.condition0IsTrue_0.val = true;
        gdjs.QuestCode.GDPlayerObjects2[k] = gdjs.QuestCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.QuestCode.GDPlayerObjects2.length = k;}if (gdjs.QuestCode.condition0IsTrue_0.val) {
/* Reuse gdjs.QuestCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.QuestCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.QuestCode.GDPlayerObjects2[i].setAnimationName("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.QuestCode.GDPlayerObjects2);

gdjs.QuestCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.QuestCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.QuestCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isUsingControl("Down") ) {
        gdjs.QuestCode.condition0IsTrue_0.val = true;
        gdjs.QuestCode.GDPlayerObjects2[k] = gdjs.QuestCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.QuestCode.GDPlayerObjects2.length = k;}if (gdjs.QuestCode.condition0IsTrue_0.val) {
/* Reuse gdjs.QuestCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.QuestCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.QuestCode.GDPlayerObjects2[i].setAnimationName("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.QuestCode.GDPlayerObjects2);

gdjs.QuestCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.QuestCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.QuestCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isUsingControl("Right") ) {
        gdjs.QuestCode.condition0IsTrue_0.val = true;
        gdjs.QuestCode.GDPlayerObjects2[k] = gdjs.QuestCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.QuestCode.GDPlayerObjects2.length = k;}if (gdjs.QuestCode.condition0IsTrue_0.val) {
/* Reuse gdjs.QuestCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.QuestCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.QuestCode.GDPlayerObjects2[i].setAnimationName("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.QuestCode.GDPlayerObjects2);

gdjs.QuestCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.QuestCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.QuestCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isUsingControl("Left") ) {
        gdjs.QuestCode.condition0IsTrue_0.val = true;
        gdjs.QuestCode.GDPlayerObjects2[k] = gdjs.QuestCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.QuestCode.GDPlayerObjects2.length = k;}if (gdjs.QuestCode.condition0IsTrue_0.val) {
/* Reuse gdjs.QuestCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.QuestCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.QuestCode.GDPlayerObjects2[i].setAnimationName("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.QuestCode.GDPlayerObjects2);

gdjs.QuestCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.QuestCode.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.QuestCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isMoving()) ) {
        gdjs.QuestCode.condition0IsTrue_0.val = true;
        gdjs.QuestCode.GDPlayerObjects2[k] = gdjs.QuestCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.QuestCode.GDPlayerObjects2.length = k;}if (gdjs.QuestCode.condition0IsTrue_0.val) {
/* Reuse gdjs.QuestCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.QuestCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.QuestCode.GDPlayerObjects2[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs.QuestCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.QuestCode.GDPlayerObjects2[i].setAnimationFrame(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.QuestCode.GDPlayerObjects1);

gdjs.QuestCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.QuestCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.QuestCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").isMoving() ) {
        gdjs.QuestCode.condition0IsTrue_0.val = true;
        gdjs.QuestCode.GDPlayerObjects1[k] = gdjs.QuestCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.QuestCode.GDPlayerObjects1.length = k;}if (gdjs.QuestCode.condition0IsTrue_0.val) {
/* Reuse gdjs.QuestCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.QuestCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.QuestCode.GDPlayerObjects1[i].playAnimation();
}
}}

}


};gdjs.QuestCode.mapOfGDgdjs_46QuestCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.QuestCode.GDPlayerObjects1});
gdjs.QuestCode.mapOfGDgdjs_46QuestCode_46GDDogObjects1Objects = Hashtable.newFrom({"Dog": gdjs.QuestCode.GDDogObjects1});
gdjs.QuestCode.eventsList2 = function(runtimeScene) {

{


gdjs.QuestCode.condition0IsTrue_0.val = false;
gdjs.QuestCode.condition1IsTrue_0.val = false;
{
gdjs.QuestCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.QuestCode.condition0IsTrue_0.val ) {
{
{gdjs.QuestCode.conditionTrue_1 = gdjs.QuestCode.condition1IsTrue_0;
gdjs.QuestCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15827620);
}
}}
if (gdjs.QuestCode.condition1IsTrue_0.val) {
{runtimeScene.getGame().getVariables().get("tasks").add(1);
}{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


};gdjs.QuestCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Dog"), gdjs.QuestCode.GDDogObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.QuestCode.GDPlayerObjects1);

gdjs.QuestCode.condition0IsTrue_0.val = false;
{
gdjs.QuestCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.QuestCode.mapOfGDgdjs_46QuestCode_46GDPlayerObjects1Objects, gdjs.QuestCode.mapOfGDgdjs_46QuestCode_46GDDogObjects1Objects, 20, false);
}if (gdjs.QuestCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.QuestCode.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.QuestCode.eventsList4 = function(runtimeScene) {

{


gdjs.QuestCode.condition0IsTrue_0.val = false;
{
gdjs.QuestCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.QuestCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CollisionDetect"), gdjs.QuestCode.GDCollisionDetectObjects1);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 6, "", 0);
}{for(var i = 0, len = gdjs.QuestCode.GDCollisionDetectObjects1.length ;i < len;++i) {
    gdjs.QuestCode.GDCollisionDetectObjects1[i].hide();
}
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1.5, "Transition", 0);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("CollisionDetect"), gdjs.QuestCode.GDCollisionDetectObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.QuestCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.QuestCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.QuestCode.GDPlayerObjects1[i].separateFromObjectsList(gdjs.QuestCode.mapOfGDgdjs_46QuestCode_46GDCollisionDetectObjects1Objects, false);
}
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.QuestCode.GDPlayerObjects1.length !== 0 ? gdjs.QuestCode.GDPlayerObjects1[0] : null), true, "", 0);
}{for(var i = 0, len = gdjs.QuestCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.QuestCode.GDPlayerObjects1[i].setZOrder((gdjs.QuestCode.GDPlayerObjects1[i].getPointY("")));
}
}}

}


{


gdjs.QuestCode.eventsList0(runtimeScene);
}


{


gdjs.QuestCode.condition0IsTrue_0.val = false;
{
gdjs.QuestCode.condition0IsTrue_0.val = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Dialogue"));
}if (gdjs.QuestCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.QuestCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


gdjs.QuestCode.eventsList3(runtimeScene);
}


{


{
}

}


};

gdjs.QuestCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.QuestCode.GDTransitionObjects1.length = 0;
gdjs.QuestCode.GDTransitionObjects2.length = 0;
gdjs.QuestCode.GDTransitionObjects3.length = 0;
gdjs.QuestCode.GDPlayerObjects1.length = 0;
gdjs.QuestCode.GDPlayerObjects2.length = 0;
gdjs.QuestCode.GDPlayerObjects3.length = 0;
gdjs.QuestCode.GDDock1Objects1.length = 0;
gdjs.QuestCode.GDDock1Objects2.length = 0;
gdjs.QuestCode.GDDock1Objects3.length = 0;
gdjs.QuestCode.GDFishermanObjects1.length = 0;
gdjs.QuestCode.GDFishermanObjects2.length = 0;
gdjs.QuestCode.GDFishermanObjects3.length = 0;
gdjs.QuestCode.GDWater1Objects1.length = 0;
gdjs.QuestCode.GDWater1Objects2.length = 0;
gdjs.QuestCode.GDWater1Objects3.length = 0;
gdjs.QuestCode.GDTextBorderObjects1.length = 0;
gdjs.QuestCode.GDTextBorderObjects2.length = 0;
gdjs.QuestCode.GDTextBorderObjects3.length = 0;
gdjs.QuestCode.GDCollisionDetectObjects1.length = 0;
gdjs.QuestCode.GDCollisionDetectObjects2.length = 0;
gdjs.QuestCode.GDCollisionDetectObjects3.length = 0;
gdjs.QuestCode.GDEObjects1.length = 0;
gdjs.QuestCode.GDEObjects2.length = 0;
gdjs.QuestCode.GDEObjects3.length = 0;
gdjs.QuestCode.GDAObjects1.length = 0;
gdjs.QuestCode.GDAObjects2.length = 0;
gdjs.QuestCode.GDAObjects3.length = 0;
gdjs.QuestCode.GDA2Objects1.length = 0;
gdjs.QuestCode.GDA2Objects2.length = 0;
gdjs.QuestCode.GDA2Objects3.length = 0;
gdjs.QuestCode.GDDialogueObjects1.length = 0;
gdjs.QuestCode.GDDialogueObjects2.length = 0;
gdjs.QuestCode.GDDialogueObjects3.length = 0;
gdjs.QuestCode.GDDialogue4Objects1.length = 0;
gdjs.QuestCode.GDDialogue4Objects2.length = 0;
gdjs.QuestCode.GDDialogue4Objects3.length = 0;
gdjs.QuestCode.GDYesButtonObjects1.length = 0;
gdjs.QuestCode.GDYesButtonObjects2.length = 0;
gdjs.QuestCode.GDYesButtonObjects3.length = 0;
gdjs.QuestCode.GDNoButtonObjects1.length = 0;
gdjs.QuestCode.GDNoButtonObjects2.length = 0;
gdjs.QuestCode.GDNoButtonObjects3.length = 0;
gdjs.QuestCode.GDCornerWaterObjects1.length = 0;
gdjs.QuestCode.GDCornerWaterObjects2.length = 0;
gdjs.QuestCode.GDCornerWaterObjects3.length = 0;
gdjs.QuestCode.GDWaterEdgeRightObjects1.length = 0;
gdjs.QuestCode.GDWaterEdgeRightObjects2.length = 0;
gdjs.QuestCode.GDWaterEdgeRightObjects3.length = 0;
gdjs.QuestCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.QuestCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.QuestCode.GDNewTiledSpriteObjects3.length = 0;
gdjs.QuestCode.GDGrassObjects1.length = 0;
gdjs.QuestCode.GDGrassObjects2.length = 0;
gdjs.QuestCode.GDGrassObjects3.length = 0;
gdjs.QuestCode.GDTree2Objects1.length = 0;
gdjs.QuestCode.GDTree2Objects2.length = 0;
gdjs.QuestCode.GDTree2Objects3.length = 0;
gdjs.QuestCode.GDNPC2Objects1.length = 0;
gdjs.QuestCode.GDNPC2Objects2.length = 0;
gdjs.QuestCode.GDNPC2Objects3.length = 0;
gdjs.QuestCode.GDBush1Objects1.length = 0;
gdjs.QuestCode.GDBush1Objects2.length = 0;
gdjs.QuestCode.GDBush1Objects3.length = 0;
gdjs.QuestCode.GDLakeTroutObjects1.length = 0;
gdjs.QuestCode.GDLakeTroutObjects2.length = 0;
gdjs.QuestCode.GDLakeTroutObjects3.length = 0;
gdjs.QuestCode.GDRock1Objects1.length = 0;
gdjs.QuestCode.GDRock1Objects2.length = 0;
gdjs.QuestCode.GDRock1Objects3.length = 0;
gdjs.QuestCode.GDDogObjects1.length = 0;
gdjs.QuestCode.GDDogObjects2.length = 0;
gdjs.QuestCode.GDDogObjects3.length = 0;
gdjs.QuestCode.GDMushroomObjects1.length = 0;
gdjs.QuestCode.GDMushroomObjects2.length = 0;
gdjs.QuestCode.GDMushroomObjects3.length = 0;

gdjs.QuestCode.eventsList4(runtimeScene);

return;

}

gdjs['QuestCode'] = gdjs.QuestCode;

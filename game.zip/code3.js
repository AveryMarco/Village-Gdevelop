gdjs.FishingCode = {};
gdjs.FishingCode.GDTransitionObjects1= [];
gdjs.FishingCode.GDTransitionObjects2= [];
gdjs.FishingCode.GDPlayerObjects1= [];
gdjs.FishingCode.GDPlayerObjects2= [];
gdjs.FishingCode.GDDock1Objects1= [];
gdjs.FishingCode.GDDock1Objects2= [];
gdjs.FishingCode.GDFishermanObjects1= [];
gdjs.FishingCode.GDFishermanObjects2= [];
gdjs.FishingCode.GDWater1Objects1= [];
gdjs.FishingCode.GDWater1Objects2= [];
gdjs.FishingCode.GDTextBorderObjects1= [];
gdjs.FishingCode.GDTextBorderObjects2= [];
gdjs.FishingCode.GDCollisionDetectObjects1= [];
gdjs.FishingCode.GDCollisionDetectObjects2= [];
gdjs.FishingCode.GDEObjects1= [];
gdjs.FishingCode.GDEObjects2= [];
gdjs.FishingCode.GDAObjects1= [];
gdjs.FishingCode.GDAObjects2= [];
gdjs.FishingCode.GDA2Objects1= [];
gdjs.FishingCode.GDA2Objects2= [];
gdjs.FishingCode.GDDialogueObjects1= [];
gdjs.FishingCode.GDDialogueObjects2= [];
gdjs.FishingCode.GDDialogue4Objects1= [];
gdjs.FishingCode.GDDialogue4Objects2= [];
gdjs.FishingCode.GDYesButtonObjects1= [];
gdjs.FishingCode.GDYesButtonObjects2= [];
gdjs.FishingCode.GDNoButtonObjects1= [];
gdjs.FishingCode.GDNoButtonObjects2= [];
gdjs.FishingCode.GDCornerWaterObjects1= [];
gdjs.FishingCode.GDCornerWaterObjects2= [];
gdjs.FishingCode.GDWaterEdgeRightObjects1= [];
gdjs.FishingCode.GDWaterEdgeRightObjects2= [];
gdjs.FishingCode.GDNewTiledSpriteObjects1= [];
gdjs.FishingCode.GDNewTiledSpriteObjects2= [];
gdjs.FishingCode.GDGrassObjects1= [];
gdjs.FishingCode.GDGrassObjects2= [];
gdjs.FishingCode.GDTree2Objects1= [];
gdjs.FishingCode.GDTree2Objects2= [];
gdjs.FishingCode.GDNPC2Objects1= [];
gdjs.FishingCode.GDNPC2Objects2= [];
gdjs.FishingCode.GDBush1Objects1= [];
gdjs.FishingCode.GDBush1Objects2= [];
gdjs.FishingCode.GDLakeTroutObjects1= [];
gdjs.FishingCode.GDLakeTroutObjects2= [];
gdjs.FishingCode.GDClownfishObjects1= [];
gdjs.FishingCode.GDClownfishObjects2= [];
gdjs.FishingCode.GDleafObjects1= [];
gdjs.FishingCode.GDleafObjects2= [];
gdjs.FishingCode.GDTangObjects1= [];
gdjs.FishingCode.GDTangObjects2= [];

gdjs.FishingCode.conditionTrue_0 = {val:false};
gdjs.FishingCode.condition0IsTrue_0 = {val:false};


gdjs.FishingCode.eventsList0 = function(runtimeScene) {

{


{
}

}


};

gdjs.FishingCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.FishingCode.GDTransitionObjects1.length = 0;
gdjs.FishingCode.GDTransitionObjects2.length = 0;
gdjs.FishingCode.GDPlayerObjects1.length = 0;
gdjs.FishingCode.GDPlayerObjects2.length = 0;
gdjs.FishingCode.GDDock1Objects1.length = 0;
gdjs.FishingCode.GDDock1Objects2.length = 0;
gdjs.FishingCode.GDFishermanObjects1.length = 0;
gdjs.FishingCode.GDFishermanObjects2.length = 0;
gdjs.FishingCode.GDWater1Objects1.length = 0;
gdjs.FishingCode.GDWater1Objects2.length = 0;
gdjs.FishingCode.GDTextBorderObjects1.length = 0;
gdjs.FishingCode.GDTextBorderObjects2.length = 0;
gdjs.FishingCode.GDCollisionDetectObjects1.length = 0;
gdjs.FishingCode.GDCollisionDetectObjects2.length = 0;
gdjs.FishingCode.GDEObjects1.length = 0;
gdjs.FishingCode.GDEObjects2.length = 0;
gdjs.FishingCode.GDAObjects1.length = 0;
gdjs.FishingCode.GDAObjects2.length = 0;
gdjs.FishingCode.GDA2Objects1.length = 0;
gdjs.FishingCode.GDA2Objects2.length = 0;
gdjs.FishingCode.GDDialogueObjects1.length = 0;
gdjs.FishingCode.GDDialogueObjects2.length = 0;
gdjs.FishingCode.GDDialogue4Objects1.length = 0;
gdjs.FishingCode.GDDialogue4Objects2.length = 0;
gdjs.FishingCode.GDYesButtonObjects1.length = 0;
gdjs.FishingCode.GDYesButtonObjects2.length = 0;
gdjs.FishingCode.GDNoButtonObjects1.length = 0;
gdjs.FishingCode.GDNoButtonObjects2.length = 0;
gdjs.FishingCode.GDCornerWaterObjects1.length = 0;
gdjs.FishingCode.GDCornerWaterObjects2.length = 0;
gdjs.FishingCode.GDWaterEdgeRightObjects1.length = 0;
gdjs.FishingCode.GDWaterEdgeRightObjects2.length = 0;
gdjs.FishingCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.FishingCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.FishingCode.GDGrassObjects1.length = 0;
gdjs.FishingCode.GDGrassObjects2.length = 0;
gdjs.FishingCode.GDTree2Objects1.length = 0;
gdjs.FishingCode.GDTree2Objects2.length = 0;
gdjs.FishingCode.GDNPC2Objects1.length = 0;
gdjs.FishingCode.GDNPC2Objects2.length = 0;
gdjs.FishingCode.GDBush1Objects1.length = 0;
gdjs.FishingCode.GDBush1Objects2.length = 0;
gdjs.FishingCode.GDLakeTroutObjects1.length = 0;
gdjs.FishingCode.GDLakeTroutObjects2.length = 0;
gdjs.FishingCode.GDClownfishObjects1.length = 0;
gdjs.FishingCode.GDClownfishObjects2.length = 0;
gdjs.FishingCode.GDleafObjects1.length = 0;
gdjs.FishingCode.GDleafObjects2.length = 0;
gdjs.FishingCode.GDTangObjects1.length = 0;
gdjs.FishingCode.GDTangObjects2.length = 0;

gdjs.FishingCode.eventsList0(runtimeScene);

return;

}

gdjs['FishingCode'] = gdjs.FishingCode;
